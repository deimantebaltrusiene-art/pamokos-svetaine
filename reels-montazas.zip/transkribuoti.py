# -*- coding: utf-8 -*-
import sys, json, os
from faster_whisper import WhisperModel

import nustatymai

K = os.path.dirname(os.path.abspath(__file__))
modelis = sys.argv[1] if len(sys.argv) > 1 else "large-v3"
m = WhisperModel(modelis, device="cpu", compute_type="int8")
segmentai, info = m.transcribe(
    os.path.join(K, "garsas.wav"),
    language="lt", word_timestamps=True, vad_filter=True,
    beam_size=5, condition_on_previous_text=False,
    # Zodynas imamas is prekes-zenklas.json: ten surasomi vardai ir pavadinimai,
    # kuriuos modelis be uzuominos iskraipo.
    initial_prompt=nustatymai.zenklas()["transkripcijos_zodynas"],
)
zodziai = []
for s in segmentai:
    print(f"[{s.start:6.2f} - {s.end:6.2f}] {s.text.strip()}", flush=True)
    for w in (s.words or []):
        zodziai.append({"pradzia": round(w.start, 3), "pabaiga": round(w.end, 3), "zodis": w.word.strip()})
json.dump(zodziai, open(os.path.join(K, f"zodziai-{modelis}.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
print(f"\nViso zodziu: {len(zodziai)} | modelis: {modelis}")
