# -*- coding: utf-8 -*-
"""Randa veida kiekviename segmente ir pasiulo, kiek zemyn nuleisti kadra.

Pakeicia rankomis parinkta VIRSUS = 0.30 atskira reiksme kiekvienam segmentui,
kad veidas visuose kirtimuose sedetu vienodai, o ne sokinetu.

Aptikimas: YuNet (modeliai/yunet.onnx, 233 KB, ateina su repozitorija).
Jis duoda ir akiu taskus, todel kadras lygiuojamas pagal akiu linija, kaip
filmuojant. Jei modelio failo nera, griztama prie Haar kaskados, kuri ateina
su opencv-python: ji silpnesne (siame video mate 15 kadru is 18, YuNet 18 is 18).
Nieko diegti nereikia, interneto nereikia, mediapipe NEREIKIA.

SVARBU: kai priartejimas z = 1.00, o saltinis jau 9:16, vertikalios atsargos
nera visai ir kadro pajudinti neimanoma. Tokie segmentai praleidziami.

Naudojimas:
    PYTHONIOENCODING=utf-8 python veido_sekimas.py

Isvestis:
    virsus.json          reiksmes montazui, montazas.py jas pasiima pats
    _veido_sekimas.png   perziura: kur atsiduria kadras kiekviename segmente
"""
import io, json, os, subprocess, sys

import cv2
import numpy as np
from PIL import Image, ImageDraw

import montazas
import perejimai

K = os.path.dirname(os.path.abspath(__file__))
LAIKINAS = os.path.join(K, "_veidai")
YUNET = os.path.join(K, "modeliai", "yunet.onnx")

# Kur kadre turi sedeti atramos taskas, kadro auksscio dalimis.
# Akims 0.33 yra treciu taisykle. Veido vidurys leidziamas zemiau.
TIKSLAS_AKYS = 0.33
TIKSLAS_VEIDO_VIDURYS = 0.38

MEGINIAI = 5            # kiek kadru paimti is segmento; imama mediana

# Saugios ribos. Uz ju veidui arba nukerpamas smakras, arba lieka per daug oro.
RIBA_ZEMIAU, RIBA_AUKSCIAU = 0.05, 0.85

YUNET_SLENKSTIS = 0.7
HAAR_KASKADA = "haarcascade_frontalface_default.xml"
HAAR_MIN_KAIMYNU = 5


def saltinio_matmenys():
    """Saltinio plotis ir aukstis is ffmpeg isvesties."""
    r = subprocess.run([montazas.FF, "-hide_banner", "-i", montazas.SALTINIS],
                       capture_output=True, text=True)
    eilute = next(x for x in r.stderr.splitlines() if "Video:" in x)
    for dalis in eilute.split(","):
        dalis = dalis.strip().split(" ")[0]
        if "x" in dalis:
            a, _, b = dalis.partition("x")
            if a.isdigit() and b.isdigit():
                return int(a), int(b)
    raise SystemExit("Nepavyko nuskaityti saltinio matmenu")


def efektyvus_priartejimai():
    """Tikri priartejimai, kokius naudos montazas.py, su perejimu priedu."""
    vardai = perejimai.parinkti(montazas.segmentu_pauzes())
    return [max(1.0, z * perejimai.PEREJIMAI[vardai[i]]["priartejimas"])
            for i, (_, _, z) in enumerate(montazas.VIDEO_SEGMENTAI)]


def istraukti_kadra(laikas, kelias):
    """Vienas kadras is saltinio i PNG."""
    subprocess.run(
        [montazas.FF, "-hide_banner", "-loglevel", "error", "-y",
         "-ss", f"{laikas:.3f}", "-i", montazas.SALTINIS,
         "-frames:v", "1", "-q:v", "2", kelias],
        check=True,
    )


def rasti_yunet(vaizdas):
    """Veido staciakampis ir akiu vidurys saltinio taskais arba None."""
    h, w = vaizdas.shape[:2]
    m = 640.0 / max(h, w)                       # mazinimas tik greiciui
    mazas = cv2.resize(vaizdas, (int(w * m), int(h * m)))
    det = cv2.FaceDetectorYN.create(YUNET, "", (mazas.shape[1], mazas.shape[0]),
                                    score_threshold=YUNET_SLENKSTIS)
    _, veidai = det.detect(mazas)
    if veidai is None or not len(veidai):
        return None
    v = max(veidai, key=lambda r: r[2] * r[3])
    x, y, fw, fh = (float(r) / m for r in v[:4])
    # YuNet taskai: 4,5 desine akis, 6,7 kaire akis
    akys = (float(v[5]) / m + float(v[7]) / m) / 2
    return (x, y, fw, fh), akys


def rasti_haar(vaizdas):
    """Atsarginis kelias, jei yunet.onnx nerastas. Akiu tasku neduoda."""
    pilkas = cv2.equalizeHist(cv2.cvtColor(vaizdas, cv2.COLOR_BGR2GRAY))
    m = 640.0 / max(pilkas.shape)
    mazas = cv2.resize(pilkas, None, fx=m, fy=m)
    kaskada = cv2.CascadeClassifier(os.path.join(cv2.data.haarcascades, HAAR_KASKADA))
    veidai = kaskada.detectMultiScale(mazas, scaleFactor=1.08,
                                      minNeighbors=HAAR_MIN_KAIMYNU, minSize=(40, 40))
    if len(veidai) == 0:
        return None
    x, y, fw, fh = (float(r) / m for r in max(veidai, key=lambda v: v[2] * v[3]))
    return (x, y, fw, fh), None


def rasti_veida(kelias, su_yunet):
    vaizdas = cv2.imread(kelias)
    if vaizdas is None:
        return None
    return rasti_yunet(vaizdas) if su_yunet else rasti_haar(vaizdas)


def kadro_geometrija(z, W, H):
    """Istempto vaizdo mastelis ir vertikali atsarga, likusi apkarpymui.

    montazas.py daro: scale(1080*z x 1920*z, increase), tada
    crop=1080:1920:(iw-1080)/2:(ih-1920)*VIRSUS. Cia atsukama atgal.
    """
    s = max(montazas.PLOTIS * z / W, montazas.AUKSTIS * z / H)
    return s, H * s - montazas.AUKSTIS


def vieta_kadre(atrama_dalimis, virsus, z, W, H):
    """Kurioje kadro vietoje atsiduria atramos taskas, esant tokiam VIRSUS."""
    s, atsarga = kadro_geometrija(z, W, H)
    return (atrama_dalimis * H * s - atsarga * virsus) / montazas.AUKSTIS


def virsus_is_atramos(atrama_dalimis, tikslas, z, W, H):
    """Kiek nuleisti kadra, kad atramos taskas atsidurtu ties tikslu."""
    s, atsarga = kadro_geometrija(z, W, H)
    if atsarga <= 1:
        return None                              # nera ka slankioti
    nuokrypis = atrama_dalimis * H * s - tikslas * montazas.AUKSTIS
    return max(RIBA_ZEMIAU, min(RIBA_AUKSCIAU, nuokrypis / atsarga))


def perziura(kadrai, virsus, priartejimai, W, H):
    """Juosta: kiekvienas segmentas su veido remeliu ir busimu kadru."""
    plyteles = []
    for i, (kelias, veidas, akys) in enumerate(kadrai):
        if kelias is None or not os.path.exists(kelias):
            continue
        atv = Image.open(kelias).convert("RGB")
        pies = ImageDraw.Draw(atv)
        s, atsarga = kadro_geometrija(priartejimai[i], W, H)
        x0 = ((W * s - montazas.PLOTIS) / 2) / s
        y0 = (atsarga * virsus[i]) / s
        pl, au = montazas.PLOTIS / s, montazas.AUKSTIS / s
        pies.rectangle([x0, y0, x0 + pl, y0 + au], outline=(255, 122, 0), width=8)
        if veidas:
            x, y, fw, fh = veidas
            pies.rectangle([x, y, x + fw, y + fh], outline=(80, 220, 120), width=5)
        if akys is not None:
            pies.line([x0, akys, x0 + pl, akys], fill=(80, 220, 120), width=3)
        tikslo_y = y0 + (TIKSLAS_AKYS if akys is not None else TIKSLAS_VEIDO_VIDURYS) * au
        pies.line([x0, tikslo_y, x0 + pl, tikslo_y], fill=(255, 122, 0), width=3)
        atv.thumbnail((360, 360))
        plyteles.append(atv)
    if not plyteles:
        return None
    pl, au = max(p.width for p in plyteles), max(p.height for p in plyteles)
    lenta = Image.new("RGB", (pl * len(plyteles), au), (24, 24, 24))
    for i, p in enumerate(plyteles):
        lenta.paste(p, (i * pl, 0))
    kelias = os.path.join(K, "_veido_sekimas.png")
    lenta.save(kelias)
    return kelias


def main():
    os.makedirs(LAIKINAS, exist_ok=True)
    su_yunet = os.path.exists(YUNET)
    W, H = saltinio_matmenys()
    priartejimai = efektyvus_priartejimai()
    print(f"Saltinis {W}x{H} | segmentu {len(montazas.VIDEO_SEGMENTAI)} "
          f"| dabartinis bendras VIRSUS {montazas.VIRSUS}")
    print("Aptikimas:", "YuNet su akiu taskais" if su_yunet
          else "Haar (yunet.onnx nerastas, tikslumas prastesnis)")
    print()

    virsus, kadrai, nerasti, nejudinami = [], [], [], []
    for i, (a, b, _) in enumerate(montazas.VIDEO_SEGMENTAI):
        z = priartejimai[i]
        akiu_dalys, veido_dalys = [], []
        pirmas_kelias, pirmas_veidas, pirmos_akys = None, None, None
        for j, t in enumerate(np.linspace(a + (b - a) * 0.15, a + (b - a) * 0.85, MEGINIAI)):
            kelias = os.path.join(LAIKINAS, f"s{i+1}_{j}.png")
            istraukti_kadra(float(t), kelias)
            radinys = rasti_veida(kelias, su_yunet)
            if radinys is None:
                continue
            (x, y, fw, fh), akys = radinys
            veido_dalys.append((y + fh / 2) / H)
            if akys is not None:
                akiu_dalys.append(akys / H)
            if pirmas_kelias is None:
                pirmas_kelias, pirmas_veidas, pirmos_akys = kelias, (x, y, fw, fh), akys
        if pirmas_kelias is None:
            pirmas_kelias = os.path.join(LAIKINAS, f"s{i+1}_0.png")

        antraste = f"  segmentas {i+1}  {a:6.2f}-{b:6.2f}s  z={z:.2f}"
        _, atsarga = kadro_geometrija(z, W, H)
        if atsarga <= 1:
            virsus.append(0.0)
            nejudinami.append(i + 1)
            print(f"{antraste}  atsargos nera, kadras nejudinamas")
            kadrai.append((pirmas_kelias, pirmas_veidas, pirmos_akys))
            continue
        if akiu_dalys:
            atrama, tikslas, vardas = float(np.median(akiu_dalys)), TIKSLAS_AKYS, "akys"
        elif veido_dalys:
            atrama, tikslas, vardas = float(np.median(veido_dalys)), TIKSLAS_VEIDO_VIDURYS, "veidas"
        else:
            virsus.append(montazas.VIRSUS)
            nerasti.append(i + 1)
            print(f"{antraste}  veido nerasta, paliekamas senas {montazas.VIRSUS}")
            kadrai.append((pirmas_kelias, pirmas_veidas, pirmos_akys))
            continue

        v = virsus_is_atramos(atrama, tikslas, z, W, H)
        buvo = vieta_kadre(atrama, montazas.VIRSUS, z, W, H)
        tapo = vieta_kadre(atrama, v, z, W, H)
        poslinkis = (v - montazas.VIRSUS) * atsarga
        rasta = len(akiu_dalys) or len(veido_dalys)
        zenklas = "" if rasta == MEGINIAI else f"  (rasta {rasta}/{MEGINIAI})"
        print(f"{antraste}  {vardas} kadre {buvo:.3f} -> {tapo:.3f}  "
              f"(VIRSUS {montazas.VIRSUS} -> {v:.3f}, {poslinkis:+.0f} px){zenklas}")
        virsus.append(round(v, 3))
        kadrai.append((pirmas_kelias, pirmas_veidas, pirmos_akys))

    json.dump({"tikslas_akys": TIKSLAS_AKYS, "virsus": virsus},
              io.open(os.path.join(K, "virsus.json"), "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    kelias = perziura(kadrai, virsus, priartejimai, W, H)

    print()
    print("Irasyta virsus.json, montazas.py ji pasiima pats.")
    print(f"Norint ideti ranka: VIRSUS_SEGMENTAI = {virsus}")
    print()
    if nejudinami:
        print(f"Segmentuose {nejudinami} priartejimo nera, tad kadro pajudinti neimanoma.")
        print("Norint ir ten lygiuoti veida, tiems segmentams reikia z bent 1.05.")
    if nerasti:
        print(f"Veido nerasta segmentuose: {nerasti}. Ten liko senas VIRSUS.")
    if kelias:
        print("Perziura:", kelias)
        print("Oranzinis staciakampis yra busimas kadras, oranzine linija yra tikslas.")
        print("Zalias staciakampis yra veidas, zalia linija yra akys.")


if __name__ == "__main__":
    sys.exit(main())
