# -*- coding: utf-8 -*-
"""Bendri nustatymai: ffmpeg, saltinio video ir prekes zenklas.

Sistema neprirista nei prie vieno kompiuterio, nei prie vieno prekes zenklo.
Viskas, kas kiekvienam zmogui skiriasi, surenkama cia:

  ffmpeg()    randamas savaime: REELS_FFMPEG, imageio-ffmpeg, PATH
  saltinis()  REELS_SALTINIS arba naujausias video is ivestis/
  zenklas()   spalvos, sriftai, zenklo zodziai is prekes-zenklas.json

Nera prekes-zenklas.json, veikia neutralus numatytieji: balta rase,
gintarinis akcentas, kartu gulintys sriftai. Niekas neluzta, tik atrodo
neutraliai. Savo faila lengviausia pasidaryti nusikopijavus
prekes-zenklas.pavyzdys.json.
"""
import json, os, shutil, sys

K = os.path.dirname(os.path.abspath(__file__))
SRIFTU_KATALOGAS = os.path.join(K, "fonts")
IVESTIES_KATALOGAS = os.path.join(K, "ivestis")

VIDEO_PLETINIAI = (".mov", ".mp4", ".m4v", ".avi", ".mkv")

# Numatytas prekes zenklas. Sazingai neutralus: cia neturi buti nei vieno
# konkretaus zmogaus spalvos ar vardo.
NUMATYTAS_ZENKLAS = {
    "vardas": "",
    "spalvos": {
        "tekstas":  "#ffffff",
        "akcentas": "#f0a83c",
        "fonas":    "#0d0d0d",
        "antra":    "#7d7d7d",
        "konturas": "#101010",
    },
    "sriftai": {
        "paprastas": {"vardas": "Lato",             "failas": "Lato-Regular.ttf"},
        "akcentas":  {"vardas": "Bebas Neue",       "failas": "BebasNeue-Regular.ttf"},
        "kursyvas":  {"vardas": "Playfair Display", "failas": "PlayfairDisplay-Italic.ttf"},
        "storas":    {"vardas": "Lato",             "failas": "Lato-Bold.ttf"},
    },
    "zenklo_zodziai": [],
    "uzrasas": {"tekstas": "", "pastraipa": ""},
    "orbitos_spalvos": [],
    "orbitos_terminai": [],
    "transkripcijos_zodynas": "Pokalbis lietuvių kalba.",
}

_atmintis = {}


# ----------------------------------------------------------------- ffmpeg

def ffmpeg():
    """Kelias iki ffmpeg. Pirma REELS_FFMPEG, paskui imageio-ffmpeg, paskui PATH."""
    if "ffmpeg" in _atmintis:
        return _atmintis["ffmpeg"]

    kelias = os.environ.get("REELS_FFMPEG", "").strip('"')
    if kelias and os.path.isfile(kelias):
        return _atmintis.setdefault("ffmpeg", kelias)

    try:
        import imageio_ffmpeg
        kelias = imageio_ffmpeg.get_ffmpeg_exe()
        if kelias and os.path.isfile(kelias):
            return _atmintis.setdefault("ffmpeg", kelias)
    except Exception:
        pass

    kelias = shutil.which("ffmpeg")
    if kelias:
        return _atmintis.setdefault("ffmpeg", kelias)

    raise RuntimeError(
        "ffmpeg nerastas. Padaryk viena is triju:\n"
        "  pip install imageio-ffmpeg\n"
        "  arba idek ffmpeg i PATH\n"
        "  arba nurodyk kelia aplinkos kintamuoju REELS_FFMPEG"
    )


# ---------------------------------------------------------------- saltinis

def saltinis(numatytas=""):
    """Kelias iki saltinio video.

    Tvarka: REELS_SALTINIS, paskui naujausias video is ivestis/, paskui tai,
    kas paduota kaip numatytas. Nieko neradus grazinamas tuscias tekstas, o
    ne klaida, kad skriptus butu galima importuoti ir be video (testai).
    """
    kelias = os.environ.get("REELS_SALTINIS", "").strip('"')
    if kelias and os.path.isfile(kelias):
        return kelias

    if os.path.isdir(IVESTIES_KATALOGAS):
        failai = [os.path.join(IVESTIES_KATALOGAS, f)
                  for f in os.listdir(IVESTIES_KATALOGAS)
                  if f.lower().endswith(VIDEO_PLETINIAI)]
        if failai:
            return max(failai, key=os.path.getmtime)

    if numatytas and os.path.isfile(numatytas):
        return numatytas
    return ""


def reikia_saltinio(kelias):
    """Aiski klaida vietoj ffmpeg burbuliavimo, kai video nerastas."""
    if kelias and os.path.isfile(kelias):
        return kelias
    raise SystemExit(
        "Saltinio video nerasta. Idek video i " + IVESTIES_KATALOGAS +
        "\narba nurodyk kelia aplinkos kintamuoju REELS_SALTINIS"
    )


# ----------------------------------------------------------- prekes zenklas

def _be_paaiskinimu(duomenys):
    """Laukai, prasidedantys pabraukimu, yra paaiskinimai zmogui, ne nustatymai."""
    if not isinstance(duomenys, dict):
        return duomenys
    return {k: _be_paaiskinimu(v) for k, v in duomenys.items() if not k.startswith("_")}


def _sulieti(numatyta, savas):
    """Savas failas gali nurodyti tik dali reiksmiu, likusios lieka numatytos."""
    isvestis = dict(numatyta)
    for raktas, verte in (_be_paaiskinimu(savas) or {}).items():
        if isinstance(verte, dict) and isinstance(isvestis.get(raktas), dict):
            isvestis[raktas] = _sulieti(isvestis[raktas], verte)
        else:
            isvestis[raktas] = verte
    return isvestis


def zenklo_failas():
    kelias = os.environ.get("REELS_ZENKLAS", "").strip('"')
    if kelias and os.path.isfile(kelias):
        return kelias
    savas = os.path.join(K, "prekes-zenklas.json")
    return savas if os.path.isfile(savas) else ""


def zenklas():
    """Prekes zenklo nustatymai. Trukstamos reiksmes paimamos is numatytuju."""
    if "zenklas" in _atmintis:
        return _atmintis["zenklas"]

    failas = zenklo_failas()
    savas = {}
    if failas:
        try:
            with open(failas, encoding="utf-8") as f:
                savas = json.load(f)
        except Exception as e:
            print("Prekes zenklo failas nenuskaitytas (%s), imami numatytieji: %s"
                  % (os.path.basename(failas), e), file=sys.stderr)

    return _atmintis.setdefault("zenklas", _sulieti(NUMATYTAS_ZENKLAS, savas))


def spalva(vardas):
    """Prekes zenklo spalva kaip #rrggbb."""
    numatyta = NUMATYTAS_ZENKLAS["spalvos"].get(vardas, "#ffffff")
    return zenklas()["spalvos"].get(vardas, numatyta)


def rgb(sesioliktainis):
    t = sesioliktainis.lstrip("#")
    if len(t) == 3:
        t = "".join(ch * 2 for ch in t)
    return tuple(int(t[i:i + 2], 16) for i in (0, 2, 4))


def ass(sesioliktainis, permatomumas=0):
    """ASS spalva. Ten rasoma atbulai ir su permatomumu prieky: &HAABBGGRR."""
    r, g, b = rgb(sesioliktainis)
    return "&H%02X%02X%02X%02X" % (permatomumas, b, g, r)


def tamsinti(sesioliktainis, dalis):
    """Tamsesnis to paties atspalvio variantas. 0.0 nieko nekeicia, 1.0 duoda juoda."""
    r, g, b = rgb(sesioliktainis)
    k = max(0.0, 1.0 - dalis)
    return "#%02x%02x%02x" % (int(r * k), int(g * k), int(b * k))


def orbitos_spalvos():
    """Trys ziedo atspalviai. Nenurodyti savo, gaminami is antros spalvos."""
    savos = zenklas().get("orbitos_spalvos") or []
    if len(savos) >= 3:
        return list(savos[:3])
    pagrindas = spalva("antra")
    return [pagrindas, tamsinti(pagrindas, 0.28), tamsinti(pagrindas, 0.56)]


# -------------------------------------------------------------------- sriftai

def _rasti_srifta(failas):
    if not failas:
        return ""
    if os.path.isabs(failas) and os.path.isfile(failas):
        return failas
    vardas = os.path.basename(failas)
    savas = os.path.join(SRIFTU_KATALOGAS, vardas)
    if os.path.isfile(savas):
        return savas
    sistemos = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts", vardas)
    if os.path.isfile(sistemos):
        return sistemos
    vietinis = os.environ.get("LOCALAPPDATA", "")
    if vietinis:
        vartotojo = os.path.join(vietinis, "Microsoft", "Windows", "Fonts", vardas)
        if os.path.isfile(vartotojo):
            return vartotojo
    return ""


def sriftas(vaidmuo):
    """Srifto vardas ir kelias pagal vaidmeni: paprastas, akcentas, kursyvas, storas.

    Nerastas sriftas nenutraukia darbo: imamas kartu gulintis atsarginis ir
    parasoma, kas nutiko.
    """
    aprasas = zenklas()["sriftai"].get(vaidmuo) or NUMATYTAS_ZENKLAS["sriftai"][vaidmuo]
    kelias = _rasti_srifta(aprasas.get("failas", ""))
    if not kelias:
        atsarginis = NUMATYTAS_ZENKLAS["sriftai"][vaidmuo]
        kelias = _rasti_srifta(atsarginis["failas"])
        print("Srifto %s nerasta, imamas %s" % (aprasas.get("failas"), atsarginis["failas"]),
              file=sys.stderr)
        aprasas = atsarginis
    return {"vardas": aprasas.get("vardas", ""), "kelias": kelias}


def paruosti_sriftus():
    """libass ima sriftus tik is fonts/, todel svetur gulintys cia nukopijuojami."""
    if not os.path.isdir(SRIFTU_KATALOGAS):
        os.makedirs(SRIFTU_KATALOGAS)
    for vaidmuo in zenklas()["sriftai"]:
        kelias = sriftas(vaidmuo)["kelias"]
        if kelias and os.path.dirname(os.path.abspath(kelias)) != SRIFTU_KATALOGAS:
            tikslas = os.path.join(SRIFTU_KATALOGAS, os.path.basename(kelias))
            if not os.path.isfile(tikslas):
                shutil.copy2(kelias, tikslas)
                print("Sriftas nukopijuotas i fonts/:", os.path.basename(kelias))


if __name__ == "__main__":
    z = zenklas()
    print("ffmpeg   :", ffmpeg())
    print("saltinis :", saltinis() or "(nerasta, idek video i ivestis/)")
    print("zenklas  :", zenklo_failas() or "(numatytasis, neutralus)")
    print("vardas   :", z["vardas"] or "(nenurodytas)")
    print("spalvos  :", ", ".join("%s %s" % (k, v) for k, v in z["spalvos"].items()))
    for vaidmuo in ("paprastas", "akcentas", "kursyvas", "storas"):
        s = sriftas(vaidmuo)
        print("sriftas %-10s: %-18s %s" % (vaidmuo, s["vardas"], s["kelias"] or "NERASTA"))
    print("zenklo zodziai:", ", ".join(z["zenklo_zodziai"]) or "(nera)")
