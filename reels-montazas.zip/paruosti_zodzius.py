# -*- coding: utf-8 -*-
"""Taiso transkripcija ir perskaiciuoja zodziu laikus i sumontuoto filmo laika."""
import json, io, os, re

K = os.path.dirname(os.path.abspath(__file__))

# Kas lieka is originalo. Viena vieta visam montazui: montazas.py, kad garsas
# ir subtitrai niekada neissiskirtu.
from montazas import GARSO_SEGMENTAI

TAISYMAI = {
    "rilsus": "REELS", "rilsų": "REELS",
    "capcato": "CAPCUT", "capcat": "CAPCUT",
    "captions": "CAPTIONS",
    "amperėjimų": "ANT PERĖJIMŲ",
    "stikerius": "STIKERIUS",
}
IŠMESTI = {"eau", "ė", "ėė", "hebra"}   # mikčiojimai ir nesamones

def naujas_laikas(t):
    praejo = 0.0
    for a, b in GARSO_SEGMENTAI:
        if t < a:
            return None
        if t <= b:
            return praejo + (t - a)
        praejo += b - a
    return None

zodziai = json.load(io.open(os.path.join(K, "zodziai-large-v3.json"), encoding="utf-8"))
isvestis = []
for z in zodziai:
    grynas = re.sub(r"[^\wąčęėįšųūž]", "", z["zodis"], flags=re.IGNORECASE).lower()
    if grynas in IŠMESTI:
        print(f"  ismesta: {z['zodis']}")
        continue
    pr, pb = naujas_laikas(z["pradzia"]), naujas_laikas(z["pabaiga"])
    if pr is None or pb is None:
        print(f"  iskirpta: {z['zodis']}")
        continue
    tekstas = z["zodis"]
    if grynas in TAISYMAI:
        galas = re.sub(r"[\wąčęėįšųūž]", "", tekstas, flags=re.IGNORECASE)
        tekstas = TAISYMAI[grynas] + galas
    isvestis.append({"pradzia": round(pr, 3), "pabaiga": round(pb, 3), "zodis": tekstas})

json.dump(isvestis, io.open(os.path.join(K, "zodziai-galutiniai.json"), "w", encoding="utf-8"),
          ensure_ascii=False, indent=1)
print(f"Zodziu: {len(isvestis)}")
print("Tekstas:", " ".join(z["zodis"] for z in isvestis))
