# -*- coding: utf-8 -*-
"""Patikrina sumontuota video pries atiduodant.

Tikrina keturis dalykus, kuriuos anksciau tekdavo gaudyti akimis arba
sumoketi klaida:

1. Technika: trukme, matmenys, kadru daznis, spalvu diapazonas, garso lygis.
2. Spalvos. Saltinio kadras apkarpomas lygiai taip pat kaip montaze, bet BE
   jokio apdorojimo, ir lyginami vidurkiai. Jei skirtumas didesnis uz RIBA_PROC,
   vadinasi, spalvos kazkur pajudejo. Tai svarbiausia patikra.
3. Subtitrai. Skaitomas subtitrai.ass ir ieskoma laike persidenganciu ivykiu.
   Butent del ju libass nustumia teksta i kadro apacia.
4. Kadru juosta PNG, kad pamatytum viska is karto.

Naudojimas:
    PYTHONIOENCODING=utf-8 python patikra.py reels.mp4

Isvestis:
    _patikra.png    kadru juosta
    ekrane          verdiktas kiekvienai patikrai
"""
import os, re, subprocess, sys

import numpy as np
from PIL import Image

import montazas
import perejimai

K = os.path.dirname(os.path.abspath(__file__))
LAIKINAS = os.path.join(K, "_patikra")

MEGINIAI = 5            # kiek kadru lyginti
RIBA_PROC = 0.6         # didesnis bendras nuokrypis procentais reiskia pakeistas spalvas
PAVIENIO_RIBA_PROC = 3.0  # pavienio kadro riba; zemiau jos tai tik kodavimo triuksmas
VIRSUTINE_DALIS = 0.50  # lyginama tik virsutine kadro puse, kur nera subtitru


def techniniai(kelias):
    """Ka ffmpeg sako apie faila."""
    r = subprocess.run([montazas.FF, "-hide_banner", "-i", kelias],
                       capture_output=True, text=True)
    t = r.stderr
    m = re.search(r"Duration:\s*(\d+):(\d+):([\d.]+)", t)
    trukme = (int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))) if m else None
    v = next((x for x in t.splitlines() if "Video:" in x), "")
    a = next((x for x in t.splitlines() if "Audio:" in x), "")
    return trukme, v.strip(), a.strip()


def garso_lygis(kelias):
    """Vidutinis ir virsutinis garso lygis decibelais."""
    r = subprocess.run(
        [montazas.FF, "-hide_banner", "-nostats", "-i", kelias,
         "-af", "volumedetect", "-f", "null", "-"],
        capture_output=True, text=True)
    vid = re.search(r"mean_volume:\s*(-?[\d.]+)", r.stderr)
    virs = re.search(r"max_volume:\s*(-?[\d.]+)", r.stderr)
    return (float(vid.group(1)) if vid else None,
            float(virs.group(1)) if virs else None)


def efektyvus_priartejimai():
    vardai = perejimai.parinkti(montazas.segmentu_pauzes())
    return [max(1.0, z * perejimai.PEREJIMAI[vardai[i]]["priartejimas"])
            for i, (_, _, z) in enumerate(montazas.VIDEO_SEGMENTAI)]


def poros():
    """Laiku poros (isvesties laikas, saltinio laikas, segmento numeris).

    Imamas kiekvieno segmento vidurys, kad nepakliutume nei i kirtima,
    nei i perejimo suliejima.
    """
    kirtimai = montazas.kirtimu_laikai()
    isvestis = []
    for i, (a, b, _) in enumerate(montazas.VIDEO_SEGMENTAI):
        if b - a < 0.8:                     # per trumpas segmentas patikrai
            continue
        isvestis.append((kirtimai[i] + (b - a) / 2, a + (b - a) / 2, i))
    # tolygiai issirenkame MEGINIAI vienetu
    if len(isvestis) <= MEGINIAI:
        return isvestis
    zingsnis = len(isvestis) / MEGINIAI
    return [isvestis[int(i * zingsnis)] for i in range(MEGINIAI)]


def be_zenkliuku(t):
    """Ar isvesties laiku t kadre nera uzdetu zenkliuku."""
    langai = [montazas.ZENKLIUKAS_1, montazas.ZENKLIUKAS_2, montazas.ROBOTUKAS]
    return not any(a <= t <= b for a, b in (l for l in langai if l))


def kadras_is_isvesties(kelias, t, i):
    tikslas = os.path.join(LAIKINAS, f"isv{i}.png")
    subprocess.run([montazas.FF, "-hide_banner", "-loglevel", "error", "-y",
                    "-ss", f"{t:.3f}", "-i", kelias, "-frames:v", "1", tikslas], check=True)
    return tikslas


def kadras_is_saltinio(t, i, virsus, z):
    """Toks pat apkarpymas kaip montaze, bet be jokio spalvu apdorojimo."""
    w = int(montazas.PLOTIS * z) // 2 * 2
    h = int(montazas.AUKSTIS * z) // 2 * 2
    vf = (f"scale={w}:{h}:force_original_aspect_ratio=increase:flags=lanczos,"
          f"crop={montazas.PLOTIS}:{montazas.AUKSTIS}:(iw-{montazas.PLOTIS})/2:"
          f"(ih-{montazas.AUKSTIS})*{virsus}")
    tikslas = os.path.join(LAIKINAS, f"salt{i}.png")
    subprocess.run([montazas.FF, "-hide_banner", "-loglevel", "error", "-y",
                    "-ss", f"{t:.3f}", "-i", montazas.SALTINIS,
                    "-frames:v", "1", "-vf", vf, tikslas], check=True)
    return tikslas


def vidurkiai(kelias):
    """Kanalu vidurkiai virsutineje kadro dalyje, kur nera subtitru."""
    a = np.asarray(Image.open(kelias).convert("RGB"), dtype=np.float64)
    return a[: int(a.shape[0] * VIRSUTINE_DALIS)].mean(axis=(0, 1))


def tikrinti_spalvas(kelias):
    """Lyginami vidurkiai per visa video, ne pavieniai kadrai.

    Viename kadre priartintuose segmentuose lieka apie 1 % kodavimo triuksmo:
    ten vaizdas pertempiamas, o x264 su aq-mode=3 sviesuma vietomis pastumia.
    Tai ne spalvu keitimas. Sudejus visus meginius, tas triuksmas issilygina,
    ir lieka butent tas skaicius, kuri tikrini pati.
    """
    priartejimai = efektyvus_priartejimai()
    virsus, _ = montazas.virsaus_sarasas()
    eilutes, sumos_s, sumos_o, itartini = [], [], [], []
    for n, (t_isv, t_salt, i) in enumerate(poros()):
        if not be_zenkliuku(t_isv):
            continue
        s = vidurkiai(kadras_is_saltinio(t_salt, n, virsus[i], priartejimai[i]))
        o = vidurkiai(kadras_is_isvesties(kelias, t_isv, n))
        proc = float(np.max(np.abs(o - s) / np.maximum(s, 1e-6)) * 100)
        sumos_s.append(s)
        sumos_o.append(o)
        if proc > PAVIENIO_RIBA_PROC:
            itartini.append((i + 1, proc))
        eilutes.append(
            f"  segmentas {i+1}  saltinis {s[0]:5.1f}/{s[1]:5.1f}/{s[2]:5.1f}   "
            f"isvestis {o[0]:5.1f}/{o[1]:5.1f}/{o[2]:5.1f}   kadre {proc:4.2f} %")
    if not sumos_s:
        return eilutes, None, itartini
    vs, vo = np.mean(sumos_s, axis=0), np.mean(sumos_o, axis=0)
    bendras = float(np.max(np.abs(vo - vs) / np.maximum(vs, 1e-6)) * 100)
    eilutes.append("")
    eilutes.append(f"  VIDURKIS   saltinis {vs[0]:5.1f}/{vs[1]:5.1f}/{vs[2]:5.1f}   "
                   f"isvestis {vo[0]:5.1f}/{vo[1]:5.1f}/{vo[2]:5.1f}   "
                   f"skirtumas {bendras:4.2f} %")
    return eilutes, bendras, itartini


def tikrinti_subtitrus():
    """ASS ivykiai negali persidengti laike, kitaip tekstas nusoka i apacia."""
    kelias = os.path.join(K, "subtitrai.ass")
    if not os.path.exists(kelias):
        return None, []
    def sek(x):
        h, m, s = x.split(":")
        return int(h) * 3600 + int(m) * 60 + float(s)
    ivykiai = []
    with open(kelias, encoding="utf-8") as f:
        for eil in f:
            if not eil.startswith("Dialogue:"):
                continue
            dalys = eil.split(",", 10)
            ivykiai.append((sek(dalys[1]), sek(dalys[2]), dalys[-1].strip()))
    ivykiai.sort()
    persidengia = []
    for i in range(1, len(ivykiai)):
        if ivykiai[i][0] < ivykiai[i - 1][1] - 0.001:
            persidengia.append((ivykiai[i - 1], ivykiai[i]))
    return len(ivykiai), persidengia


def juosta(kelias, trukme):
    os.makedirs(LAIKINAS, exist_ok=True)
    plyteles = []
    for i, d in enumerate(np.linspace(0.04, 0.96, 8)):
        p = os.path.join(LAIKINAS, f"juosta{i}.png")
        subprocess.run([montazas.FF, "-hide_banner", "-loglevel", "error", "-y",
                        "-ss", f"{trukme * d:.3f}", "-i", kelias,
                        "-frames:v", "1", p], check=True)
        if os.path.exists(p):
            atv = Image.open(p).convert("RGB")
            atv.thumbnail((240, 240))
            plyteles.append(atv)
    if not plyteles:
        return None
    pl, au = max(p.width for p in plyteles), max(p.height for p in plyteles)
    lenta = Image.new("RGB", (pl * len(plyteles), au), (24, 24, 24))
    for i, p in enumerate(plyteles):
        lenta.paste(p, (i * pl, 0))
    tikslas = os.path.join(K, "_patikra.png")
    lenta.save(tikslas)
    return tikslas


def main():
    kelias = sys.argv[1] if len(sys.argv) > 1 else os.path.join(K, "reels.mp4")
    if not os.path.exists(kelias):
        raise SystemExit(f"Nera failo: {kelias}")
    os.makedirs(LAIKINAS, exist_ok=True)
    klaidos = []

    print(f"Tikrinamas: {kelias}\n")

    trukme, v, a = techniniai(kelias)
    vid, virs = garso_lygis(kelias)
    laukiama = montazas.foto_trukme() + sum(b - x for x, b, _ in montazas.VIDEO_SEGMENTAI)
    print("1. TECHNIKA")
    print(f"  trukme {trukme:.2f} s (montazas skaiciavo {laukiama:.2f} s)")
    print(f"  {v}")
    print(f"  {a}")
    print(f"  garsas: vidutinis {vid} dB, virsutinis {virs} dB")
    if trukme and abs(trukme - laukiama) > 0.25:
        klaidos.append(f"trukme skiriasi nuo skaiciuotos {abs(trukme - laukiama):.2f} s")
    if virs is not None and virs > -0.5:
        klaidos.append(f"garsas kerpasi virsuje (max {virs} dB)")
    print()

    print("2. SPALVOS (virsutine kadro puse, saltinis apkarpytas taip pat, bet neapdorotas)")
    eilutes, bendras, itartini = tikrinti_spalvas(kelias)
    for e in eilutes:
        print(e)
    if bendras is None:
        print("  nebuvo tinkamu kadru palyginimui")
    elif bendras <= RIBA_PROC:
        print(f"  GERAI: bendras skirtumas {bendras:.2f} %, spalvos nepaliestos")
    else:
        klaidos.append(f"spalvos pajudejo, bendras skirtumas {bendras:.2f} %")
        print(f"  DEMESIO: bendras skirtumas {bendras:.2f} %")
    for nr, proc in itartini:
        print(f"  Pastaba: segmente {nr} pavienis kadras skiriasi {proc:.2f} %, verta pasiziureti.")
    print()

    print("3. SUBTITRAI")
    kiek, persidengia = tikrinti_subtitrus()
    if kiek is None:
        print("  subtitrai.ass nerastas, praleista")
    else:
        print(f"  ivykiu {kiek}")
        if persidengia:
            klaidos.append(f"ASS ivykiai persidengia {len(persidengia)} vietose")
            for pirmas, antras in persidengia[:5]:
                print(f"  PERSIDENGIA: {pirmas[0]:.2f}-{pirmas[1]:.2f} ir "
                      f"{antras[0]:.2f}-{antras[1]:.2f}")
            print("  Del to libass nustumia teksta i kadro apacia.")
        else:
            print("  GERAI: persidengimu nera, tekstas liks savo vietoje")
    print()

    p = juosta(kelias, trukme or 10)
    print("4. KADRU JUOSTA")
    print("  ", p if p else "nepavyko")
    print()

    if klaidos:
        print("VERDIKTAS: rasta problemu")
        for k in klaidos:
            print("  -", k)
        return 1
    print("VERDIKTAS: viskas svaru")
    return 0


if __name__ == "__main__":
    sys.exit(main())
