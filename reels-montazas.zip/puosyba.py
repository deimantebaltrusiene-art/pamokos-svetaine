# -*- coding: utf-8 -*-
"""Riso prekes zenklo lipdukus prie istartu zodziu ir laiko puosybos riba.

Du ribojimai, kad lipdukai nesokinetu be reikalo:
  tik pirmas to zodzio pasikartojimas,
  tik akcentinis zodis (ta pati sprendima daro subtitrai.py).
"""
import os
import subtitrai

PUOSYBOS_RIBA = 6
PLETINIAI = (".png", ".webp")


def skaityti_katalogas(aplankas):
    """Grazina zodyna {zodis: kelias}. Failo vardas yra zodis, prie kurio risama."""
    katalogas = {}
    if not os.path.isdir(aplankas):
        return katalogas
    for vardas in sorted(os.listdir(aplankas)):
        saknis, pletinys = os.path.splitext(vardas)
        if pletinys.lower() in PLETINIAI:
            katalogas[saknis.lower()] = os.path.join(aplankas, vardas)
    return katalogas


def akcentiniai(zodziai):
    """Grazina indeksu aibe tu zodziu, kurie subtitruose gauna akcenta arba zenkla."""
    blokai = subtitrai.grupuoti(zodziai)
    isvestis, slinktis = set(), 0
    for blokas in blokai:
        v = subtitrai.vaidmenys(blokas)
        for i, vaidmuo in enumerate(v):
            if vaidmuo in ("akcentas", "zenklas"):
                isvestis.add(slinktis + i)
        slinktis += len(blokas)
    return isvestis


def parinkti(zodziai, katalogas):
    """Grazina sarasa {laikas, failas, zodis}, surusiuota pagal laika, neviresijant ribos."""
    akcentai = akcentiniai(zodziai)
    panaudoti, isvestis = set(), []
    for i, z in enumerate(zodziai):
        raktas = subtitrai.grynas(z["zodis"])
        if raktas not in katalogas or raktas in panaudoti or i not in akcentai:
            continue
        panaudoti.add(raktas)
        isvestis.append({"laikas": z["pradzia"], "failas": katalogas[raktas],
                         "zodis": z["zodis"]})
    isvestis.sort(key=lambda x: x["laikas"])
    if len(isvestis) > PUOSYBOS_RIBA:
        print("Puosybos per daug: %d, riba %d. Paliekami ankstyviausi."
              % (len(isvestis), PUOSYBOS_RIBA))
        isvestis = isvestis[:PUOSYBOS_RIBA]
    return isvestis
