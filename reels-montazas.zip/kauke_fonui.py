# -*- coding: utf-8 -*-
"""Kauke fonui sulieti: centre zmogus lieka ryskus, krastai svelniai suliejami.

Segmentacijos cia nera ir nereikia. Zmogus sedi kadro viduryje, todel minksta
elipse duoda tokia pati ispudi kaip mazas rysio gylis fotoaparate, o kadrui
judant nieko neatplesia ir nemirga, kaip mirgetu kadras po kadro skaiciuojama
segmentacija.

Balta reiskia „imk ryskuji vaizda“, juoda „imk sulietaji“ (ffmpeg maskedmerge).
"""
import math, os, sys
from PIL import Image, ImageFilter

K = os.path.dirname(os.path.abspath(__file__))
PLOTIS, AUKSTIS = 1080, 1920

CENTRAS = (0.50, 0.52)       # zmogus kadre, dalimis
SPINDULIAI = (0.46, 0.40)    # elipses puvasiai, dalimis
MINKSTUMAS = 90              # kiek taskų trunka perejimas is ryskaus i sulieta


def sukurti(isvestis):
    m = 160
    h = int(m * AUKSTIS / PLOTIS)
    kauke = Image.new("L", (m, h))
    px = kauke.load()
    for y in range(h):
        for x in range(m):
            nx = (x / (m - 1) - CENTRAS[0]) / SPINDULIAI[0]
            ny = (y / (h - 1) - CENTRAS[1]) / SPINDULIAI[1]
            r = math.hypot(nx, ny)
            # 1 viduje, 0 isoreje, su tolygiu perejimu ties riba
            v = 1.0 - max(0.0, min(1.0, (r - 0.72) / 0.55))
            px[x, y] = int(255 * v ** 0.8)
    kauke = kauke.resize((PLOTIS, AUKSTIS), Image.BICUBIC)
    kauke = kauke.filter(ImageFilter.GaussianBlur(radius=MINKSTUMAS / 3))
    kauke.convert("RGB").save(isvestis)
    print(f"Kauke fonui: {os.path.basename(isvestis)}")


if __name__ == "__main__":
    sukurti(os.path.join(K, sys.argv[1] if len(sys.argv) > 1 else "kauke-fonui.png"))
