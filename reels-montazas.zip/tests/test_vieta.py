# -*- coding: utf-8 -*-
import os, sys
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import vieta

PLOTIS, AUKSTIS = 1080, 1920


def lygus_kadras():
    return np.full((AUKSTIS, PLOTIS), 128, dtype=np.uint8)


def test_grazina_koordinates_kadro_ribose():
    x, y = vieta.rasti(lygus_kadras(), 200, 200)
    assert 0 <= x <= PLOTIS - 200
    assert 0 <= y <= AUKSTIS - 200


def test_niekada_nepatenka_i_veido_zona():
    x, y = vieta.rasti(lygus_kadras(), 200, 200)
    vx1, vy1, vx2, vy2 = vieta.VEIDO_ZONA
    persidengia = (x < vx2 * PLOTIS and x + 200 > vx1 * PLOTIS
                   and y < vy2 * AUKSTIS and y + 200 > vy1 * AUKSTIS)
    assert not persidengia


def test_niekada_nepatenka_i_subtitru_zona():
    x, y = vieta.rasti(lygus_kadras(), 200, 200)
    _, sy1, _, sy2 = vieta.SUBTITRU_ZONA
    persidengia = y < sy2 * AUKSTIS and y + 200 > sy1 * AUKSTIS
    assert not persidengia


def test_renkasi_ramesni_plota():
    kadras = lygus_kadras()
    # visa kaire puse margina, desine lieka lygi
    # (margumas tik viename kampe netiktu: esant lygybei laimi pirmas rastas
    #  langelis, tad algoritmas teisetai grazintu virsutini kaire kampa)
    kadras[:, :PLOTIS // 2] = np.random.default_rng(1).integers(
        0, 255, (AUKSTIS, PLOTIS // 2), dtype=np.uint8)
    x, _ = vieta.rasti(kadras, 150, 150)
    assert x > PLOTIS // 2, "turejo rinktis ramesne desine puse"


def test_per_didelis_lipdukas_grazina_none():
    assert vieta.rasti(lygus_kadras(), 2000, 2000) is None
