# -*- coding: utf-8 -*-
import os, sys, wave, subprocess
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import perejimai

K = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
GARSAI = os.path.join(K, "garsai")


def test_visi_kataloge_minimi_garsai_egzistuoja():
    subprocess.run([sys.executable, os.path.join(K, "garsai.py")], check=True, cwd=K)
    reikia = {p["garsas"] for p in perejimai.PEREJIMAI.values() if p["garsas"]}
    for vardas in reikia:
        kelias = os.path.join(GARSAI, vardas + ".wav")
        assert os.path.exists(kelias), vardas


def test_pustelejimas_yra_svelnus_ir_trumpas():
    kelias = os.path.join(GARSAI, "pustelejimas.wav")
    with wave.open(kelias) as f:
        trukme = f.getnframes() / f.getframerate()
        assert f.getframerate() == 48000
        assert f.getnchannels() == 1
        assert 0.20 <= trukme <= 0.60, trukme
