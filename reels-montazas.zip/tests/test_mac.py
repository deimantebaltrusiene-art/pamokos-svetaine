# -*- coding: utf-8 -*-
"""Mac ir Linux: sriftai randami ju aplankuose, ffmpeg be subtitru nepasirenkamas."""
import os, sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import nustatymai


def test_sriftas_randamas_mac_vartotojo_aplanke(tmp_path, monkeypatch):
    aplankas = tmp_path / "Library" / "Fonts"
    aplankas.mkdir(parents=True)
    (aplankas / "ManoSriftas.ttf").write_bytes(b"x")
    monkeypatch.setattr(os.path, "expanduser", lambda p: str(tmp_path) if p == "~" else p)
    monkeypatch.setenv("WINDIR", str(tmp_path / "nera"))
    monkeypatch.delenv("LOCALAPPDATA", raising=False)
    assert nustatymai._rasti_srifta("ManoSriftas.ttf") == str(aplankas / "ManoSriftas.ttf")


def test_pirmenybe_ffmpeg_kuris_moka_subtitrus(tmp_path, monkeypatch):
    be = tmp_path / "be-libass"
    su = tmp_path / "su-libass"
    be.write_bytes(b"")
    su.write_bytes(b"")
    monkeypatch.setattr(nustatymai, "_atmintis", {})
    monkeypatch.setenv("REELS_FFMPEG", str(be))
    monkeypatch.setattr(nustatymai.shutil, "which", lambda v: str(su))
    import imageio_ffmpeg
    monkeypatch.setattr(imageio_ffmpeg, "get_ffmpeg_exe", lambda: str(be))
    monkeypatch.setattr(nustatymai, "turi_subtitrus", lambda k: k == str(su))
    assert nustatymai.ffmpeg() == str(su)


def test_jei_niekas_nemoka_grazinamas_pirmas(tmp_path, monkeypatch):
    be = tmp_path / "be-libass"
    be.write_bytes(b"")
    monkeypatch.setattr(nustatymai, "_atmintis", {})
    monkeypatch.setenv("REELS_FFMPEG", str(be))
    monkeypatch.setattr(nustatymai, "turi_subtitrus", lambda k: False)
    assert nustatymai.ffmpeg() == str(be)
