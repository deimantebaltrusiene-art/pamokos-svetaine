# -*- coding: utf-8 -*-
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import perejimai


def test_katalogas_turi_visus_penkis():
    assert set(perejimai.PEREJIMAI) == {
        "kirtis", "smugis", "minkstas", "taskas", "ikvepimas"}


def test_kiekvienas_turi_butinus_laukus():
    for vardas, p in perejimai.PEREJIMAI.items():
        assert "garsas" in p, vardas
        assert "garsumas" in p, vardas
        assert "priartejimas" in p, vardas
        assert "suliejimas" in p, vardas


def test_kirtis_yra_tylus_ir_be_efekto():
    k = perejimai.PEREJIMAI["kirtis"]
    assert k["garsas"] is None
    assert k["garsumas"] == 0.0
    assert k["suliejimas"] == 0.0
    assert k["priartejimas"] == 1.0


def test_pirmas_segmentas_visada_kirtis():
    assert perejimai.parinkti([0.0, 0.1, 0.1])[0] == "kirtis"


def test_paskutinis_yra_taskas_o_pries_ji_ikvepimas():
    v = perejimai.parinkti([0.0, 0.1, 0.1, 0.1, 0.1])
    assert v[-1] == "taskas"
    assert v[-2] == "ikvepimas"


def test_ilga_pauze_duoda_smugi():
    v = perejimai.parinkti([0.0, 0.60, 0.1, 0.1, 0.1])
    assert v[1] == "smugis"


def test_trumpa_pauze_lieka_kirtis():
    v = perejimai.parinkti([0.0, 0.10, 0.1, 0.1, 0.1])
    assert v[1] == "kirtis"


def test_trumpame_video_tik_paskutinis_zymimas():
    v = perejimai.parinkti([0.0, 0.1, 0.1])
    assert v[-1] == "taskas"
    assert "ikvepimas" not in v


def test_garsumas_niekada_nevirsija_ribos():
    for p in perejimai.PEREJIMAI.values():
        assert p["garsumas"] <= 0.68


def test_priartejimas_niekada_nemazesnis_uz_viena():
    # montazas.py naudoja scale plius crop iki fiksuoto PLOTIS x AUKSTIS.
    # Jei priartejimas < 1.00, scale tikslas taptu mazesnis uz crop ir
    # ffmpeg lustu su "Invalid too big or non positive size". Sis konvejeris
    # negali atitolinti zemiau originalaus kadro, nes nebutu is ko iskirpti.
    for vardas, p in perejimai.PEREJIMAI.items():
        assert p["priartejimas"] >= 1.00, vardas
