# -*- coding: utf-8 -*-
import io, os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import tylos
import patikra


# --- tylos.py ---------------------------------------------------------------

def test_tylos_iskerpamos_is_vidurio():
    segmentai = tylos.kalbos_segmentai([(5.0, 7.0)], 12.0)
    assert len(segmentai) == 2
    assert segmentai[0][1] < segmentai[1][0]      # tarp ju liko skyle


def test_atsarga_palieka_kalbos_galus():
    """Pjuvis daromas kiek veliau ir kiek anksciau, kad nenukastu zodziu galu."""
    (_, pirmo_galas), (antro_pradzia, _) = tylos.kalbos_segmentai([(5.0, 7.0)], 12.0)
    assert pirmo_galas > 5.0
    assert antro_pradzia < 7.0


def test_uodega_nupjaunama():
    """Tyla be pabaigos reiskia, kad likusi video dalis ismetama."""
    segmentai = tylos.kalbos_segmentai([(8.0, None)], 12.0)
    assert len(segmentai) == 1
    assert segmentai[0][1] <= 8.2


def test_per_trumpi_likuciai_nepaliekami():
    """Uz MIN_SEGMENTAS trumpesnis gabalas netampa atskiru segmentu."""
    segmentai = tylos.kalbos_segmentai([(0.1, 3.0), (3.1, 6.0)], 8.0)
    assert all(b - a >= tylos.MIN_SEGMENTAS for a, b in segmentai)


def test_be_tylu_lieka_visas_video():
    segmentai = tylos.kalbos_segmentai([], 10.0)
    assert segmentai == [(0.0, 10.0)]


# --- patikra.py -------------------------------------------------------------

def ass_failas(kelias, ivykiai):
    eil = ["[Events]", "Format: Layer, Start, End, Style, Name, "
           "MarginL, MarginR, MarginV, Effect, Text"]
    for a, b in ivykiai:
        eil.append(f"Dialogue: 0,0:00:0{a:.2f},0:00:0{b:.2f},Vardas,,0,0,0,,tekstas")
    io.open(kelias, "w", encoding="utf-8").write("\n".join(eil))


def test_persidengimas_sugaunamas(tmp_path, monkeypatch):
    kelias = tmp_path / "subtitrai.ass"
    ass_failas(kelias, [(1.00, 2.00), (1.50, 3.00)])
    monkeypatch.setattr(patikra, "K", str(tmp_path))
    kiek, persidengia = patikra.tikrinti_subtitrus()
    assert kiek == 2
    assert len(persidengia) == 1


def test_svarus_subtitrai_praeina(tmp_path, monkeypatch):
    kelias = tmp_path / "subtitrai.ass"
    ass_failas(kelias, [(1.00, 2.00), (2.00, 3.00), (3.00, 4.00)])
    monkeypatch.setattr(patikra, "K", str(tmp_path))
    kiek, persidengia = patikra.tikrinti_subtitrus()
    assert kiek == 3
    assert persidengia == []


def test_nera_ass_failo_neluzta(tmp_path, monkeypatch):
    monkeypatch.setattr(patikra, "K", str(tmp_path))
    kiek, persidengia = patikra.tikrinti_subtitrus()
    assert kiek is None


def test_zenkliuku_langai_praleidziami():
    """Kadrai su uzdetais zenkliukais netinka spalvu palyginimui."""
    import montazas
    a, b = montazas.ROBOTUKAS
    assert not patikra.be_zenkliuku((a + b) / 2)
    assert patikra.be_zenkliuku(b + 0.5)
