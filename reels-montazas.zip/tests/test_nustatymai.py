# -*- coding: utf-8 -*-
"""Nustatymai: ar sistema tikrai neprirista prie vieno kompiuterio ir vieno zenklo.

Sitie testai saugo butent ta, del ko viskas buvo perdaryta: kad dalyvio
kompiuteryje, kur nera nei to paties kelio, nei tu paciu spalvu, niekas neluztu.
"""
import io, json, os, sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import nustatymai


def svarus():
    """Nustatymai be atminties: kiekvienas testas skaito is naujo."""
    nustatymai._atmintis.clear()


def test_kode_nera_nei_vieno_absoliutaus_kelio():
    """Joks skriptas neturi ziureti i konkretaus zmogaus diska."""
    saknis = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    praleisti = {"archyvas", "bandymai", "tests", "__pycache__"}
    itartini = []
    for aplankas, aplankai, failai in os.walk(saknis):
        aplankai[:] = [a for a in aplankai if a not in praleisti]
        for f in failai:
            if not f.endswith(".py"):
                continue
            kelias = os.path.join(aplankas, f)
            for nr, eilute in enumerate(io.open(kelias, encoding="utf-8"), 1):
                if "C:\\Users\\" in eilute and "REELS_" not in eilute:
                    itartini.append("%s:%d" % (os.path.relpath(kelias, saknis), nr))
    assert not itartini, "absoliutus keliai: " + ", ".join(itartini)


def test_kode_nera_konkretaus_zenklo_spalvu():
    """Spalvos gyvena prekes-zenklas.json. Kode jos reiskia, kad kazkas prirakinta."""
    saknis = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    praleisti = {"archyvas", "bandymai", "tests", "__pycache__"}
    zenklo_spalvos = ("e88a5e", "efe6dd", "5a6e5c", "d97757", "00e86e",
                      "5e8ae8", "dde6ef", "5777d9")
    rasta = []
    for aplankas, aplankai, failai in os.walk(saknis):
        aplankai[:] = [a for a in aplankai if a not in praleisti]
        for f in failai:
            if not f.endswith(".py"):
                continue
            kelias = os.path.join(aplankas, f)
            for nr, eilute in enumerate(io.open(kelias, encoding="utf-8"), 1):
                for spalva in zenklo_spalvos:
                    if spalva in eilute.lower():
                        rasta.append("%s:%d %s" % (os.path.relpath(kelias, saknis), nr, spalva))
    assert not rasta, "zenklo spalvos kode: " + ", ".join(rasta)


def test_zenklo_failo_nera_veikia_neutralus_numatytieji(tmp_path, monkeypatch):
    svarus()
    monkeypatch.delenv("REELS_ZENKLAS", raising=False)
    monkeypatch.setattr(nustatymai, "K", str(tmp_path))   # tuscias aplankas, kaip pas dalyvi
    z = nustatymai.zenklas()
    assert z["vardas"] == ""
    assert z["zenklo_zodziai"] == []
    assert z["spalvos"]["tekstas"] == "#ffffff"
    svarus()


def test_zenklas_gali_nurodyti_tik_dali_reiksmiu(tmp_path, monkeypatch):
    """Dalyviui uztenka irasyti dvi spalvas, likusios lieka numatytos."""
    svarus()
    failas = tmp_path / "zenklas.json"
    failas.write_text(json.dumps({"spalvos": {"akcentas": "#123456"}}), encoding="utf-8")
    monkeypatch.setenv("REELS_ZENKLAS", str(failas))
    assert nustatymai.spalva("akcentas") == "#123456"
    assert nustatymai.spalva("tekstas") == "#ffffff"
    assert "paprastas" in nustatymai.zenklas()["sriftai"]
    svarus()


def test_ass_spalva_rasoma_atbulai():
    """ASS nori &HAABBGGRR. Sumaisius kanalus, subtitrai buna melyni vietoj oranziniu."""
    assert nustatymai.ass("#efe6dd") == "&H00DDE6EF"
    assert nustatymai.ass("#e88a5e") == "&H005E8AE8"
    assert nustatymai.ass("#000000", 128) == "&H80000000"


def test_rgb_priima_ir_trumpa_uzrasa():
    assert nustatymai.rgb("#fff") == (255, 255, 255)
    assert nustatymai.rgb("5a6e5c") == (90, 110, 92)


def test_orbitos_spalvos_gaminamos_is_antros_spalvos(tmp_path, monkeypatch):
    svarus()
    failas = tmp_path / "zenklas.json"
    failas.write_text(json.dumps({"spalvos": {"antra": "#808080"}}), encoding="utf-8")
    monkeypatch.setenv("REELS_ZENKLAS", str(failas))
    sviesi, vidurine, tamsi = nustatymai.orbitos_spalvos()
    assert sviesi == "#808080"
    assert nustatymai.rgb(vidurine)[0] < nustatymai.rgb(sviesi)[0]
    assert nustatymai.rgb(tamsi)[0] < nustatymai.rgb(vidurine)[0]
    svarus()


def test_savos_orbitos_spalvos_nugali(tmp_path, monkeypatch):
    svarus()
    failas = tmp_path / "zenklas.json"
    failas.write_text(json.dumps({"orbitos_spalvos": ["#111111", "#222222", "#333333"]}),
                      encoding="utf-8")
    monkeypatch.setenv("REELS_ZENKLAS", str(failas))
    assert nustatymai.orbitos_spalvos() == ["#111111", "#222222", "#333333"]
    svarus()


def test_nerastas_sriftas_nenutraukia_darbo(tmp_path, monkeypatch, capsys):
    svarus()
    failas = tmp_path / "zenklas.json"
    failas.write_text(json.dumps({"sriftai": {"paprastas": {"vardas": "Nera",
                                                            "failas": "nera-tokio.ttf"}}}),
                      encoding="utf-8")
    monkeypatch.setenv("REELS_ZENKLAS", str(failas))
    s = nustatymai.sriftas("paprastas")
    assert s["vardas"] == "Lato"
    assert os.path.isfile(s["kelias"])
    svarus()


def test_saltinis_imamas_is_aplinkos_kintamojo(tmp_path, monkeypatch):
    video = tmp_path / "mano.mov"
    video.write_bytes(b"ne video, bet failas yra")
    monkeypatch.setenv("REELS_SALTINIS", str(video))
    assert nustatymai.saltinis() == str(video)


def test_saltinio_nera_negriauna_importo(monkeypatch, tmp_path):
    """Skriptus turi buti galima importuoti ir tada, kai video dar nera."""
    monkeypatch.setenv("REELS_SALTINIS", str(tmp_path / "nera.mov"))
    monkeypatch.setattr(nustatymai, "IVESTIES_KATALOGAS", str(tmp_path / "tuscia"))
    assert nustatymai.saltinis() == ""


def test_reikia_saltinio_pasako_ka_daryti(tmp_path):
    try:
        nustatymai.reikia_saltinio("")
    except SystemExit as e:
        assert "ivestis" in str(e).lower() or "REELS_SALTINIS" in str(e)
    else:
        raise AssertionError("turejo buti SystemExit")
