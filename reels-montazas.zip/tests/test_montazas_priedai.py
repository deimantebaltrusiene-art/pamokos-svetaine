# -*- coding: utf-8 -*-
"""Montazas neturi luzti, kai nera nebutinu priedu (nuotraukos, zenkliuku, kaukes).

Naujas zmogus gauna sistema be autores nuotraukos ir stikeriu. Montazas turi
tada eiti be ju, o ne luzti renderio gale.
"""
import os, subprocess, sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import montazas
import nustatymai


def _komanda(monkeypatch, esami):
    monkeypatch.setattr(montazas, "yra", lambda failas: failas in esami)
    monkeypatch.setattr(montazas, "saltinio_diapazonas", lambda: "tv")
    monkeypatch.setattr(nustatymai, "reikia_saltinio", lambda *a: None)
    monkeypatch.setattr(nustatymai, "paruosti_sriftus", lambda: None)
    pagauta = {}

    class R:
        returncode = 0

    def netikras(args, *a, **k):
        pagauta["cmd"] = args
        return R()

    monkeypatch.setattr(subprocess, "run", netikras)
    assert montazas.statyti("x.mp4") == 0
    return pagauta["cmd"]


def test_be_jokiu_priedu_komanda_be_ju_failu(monkeypatch):
    cmd = _komanda(monkeypatch, set())
    tekstas = " ".join(cmd)
    for failas in (montazas.NUOTRAUKA, montazas.ZENKLIUKO_FAILAS,
                   montazas.ROBOTUKO_FAILAS, montazas.KAUKE):
        assert failas not in tekstas
    grafas = cmd[cmd.index("-filter_complex") + 1]
    assert "[v0]" not in grafas
    assert "concat=n=%d:v=1" % len(montazas.VIDEO_SEGMENTAI) in grafas
    assert "overlay" not in grafas


def test_ivesciu_numeriai_atitinka_eile(monkeypatch):
    import re
    cmd = _komanda(monkeypatch, set())
    ivestys = [cmd[i + 1] for i, x in enumerate(cmd) if x == "-i"]
    grafas = cmd[cmd.index("-filter_complex") + 1]
    # kiekviena nuoroda [N:v] ar [N:a] turi rodyti i esama ivesti
    for n in re.findall(r"\[(\d+):[av]\]", grafas):
        assert int(n) < len(ivestys)
    # stikeriu pop (garsumas 0.6) ir nuotraukos riseris dingsta kartu su priedais
    assert "volume=0.6[pp" not in grafas
    assert "[riseris]" not in grafas


def test_be_nuotraukos_kirtimai_prasideda_nuo_nulio(monkeypatch):
    monkeypatch.setattr(montazas, "yra", lambda failas: False)
    assert montazas.kirtimu_laikai()[0] == 0.0
