# -*- coding: utf-8 -*-
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import veido_sekimas as vs
import montazas

W, H = 1080, 1920          # saltinis jau 9:16, kaip telefono selfis


def test_be_priartejimo_atsargos_nera():
    """Kai z = 1.00 ir saltinis jau 9:16, kadro pajudinti neimanoma."""
    _, atsarga = vs.kadro_geometrija(1.00, W, H)
    assert atsarga <= 1
    assert vs.virsus_is_atramos(0.45, vs.TIKSLAS_AKYS, 1.00, W, H) is None


def test_priartejimas_atveria_atsarga():
    _, atsarga = vs.kadro_geometrija(1.10, W, H)
    assert abs(atsarga - 192) < 1        # 1920 * 0.10


def test_atrama_atsiduria_ties_tikslu():
    """Apskaiciuotas VIRSUS turi atvesti akis butent i TIKSLAS_AKYS."""
    for z in (1.05, 1.10, 1.25):
        for atrama in (0.36, 0.42, 0.48):
            v = vs.virsus_is_atramos(atrama, vs.TIKSLAS_AKYS, z, W, H)
            if v in (vs.RIBA_ZEMIAU, vs.RIBA_AUKSCIAU):
                continue                 # atsitrenke i saugia riba, tai tvarkoje
            assert abs(vs.vieta_kadre(atrama, v, z, W, H) - vs.TIKSLAS_AKYS) < 0.001


def test_niekada_neisejama_uz_saugiu_ribu():
    for atrama in (0.05, 0.30, 0.50, 0.95):
        v = vs.virsus_is_atramos(atrama, vs.TIKSLAS_AKYS, 1.10, W, H)
        assert vs.RIBA_ZEMIAU <= v <= vs.RIBA_AUKSCIAU


def test_zemiau_esancios_akys_nuleidzia_kadra():
    """Kuo zemiau veidas saltinyje, tuo labiau kadras turi slinkti zemyn."""
    auksciau = vs.virsus_is_atramos(0.38, vs.TIKSLAS_AKYS, 1.20, W, H)
    zemiau = vs.virsus_is_atramos(0.46, vs.TIKSLAS_AKYS, 1.20, W, H)
    assert zemiau > auksciau


def test_priartejimai_sutampa_su_montazu():
    """veido_sekimas turi skaiciuoti tuos pacius z, kokius naudos montazas."""
    import perejimai
    vardai = perejimai.parinkti(montazas.segmentu_pauzes())
    laukiami = [max(1.0, z * perejimai.PEREJIMAI[vardai[i]]["priartejimas"])
                for i, (_, _, z) in enumerate(montazas.VIDEO_SEGMENTAI)]
    assert vs.efektyvus_priartejimai() == laukiami


def test_montazas_pasiima_virsu_kiekvienam_segmentui():
    sarasas, _ = montazas.virsaus_sarasas()
    assert len(sarasas) == len(montazas.VIDEO_SEGMENTAI)
    assert all(0.0 <= v <= 1.0 for v in sarasas)
