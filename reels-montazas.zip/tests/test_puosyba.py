# -*- coding: utf-8 -*-
import os, sys
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import puosyba


def z(zodis, pradzia, pabaiga):
    return {"zodis": zodis, "pradzia": pradzia, "pabaiga": pabaiga}


def test_riba_yra_sesi():
    assert puosyba.PUOSYBOS_RIBA == 6


def test_akcentinis_zodis_gauna_lipduka():
    zodziai = [z("Skrendam", 0.0, 0.5), z("i", 0.5, 0.7), z("KOSMOSAS", 0.7, 1.4)]
    r = puosyba.parinkti(zodziai, {"kosmosas": "overlays/kosmosas.png"})
    assert len(r) == 1
    assert r[0]["failas"] == "overlays/kosmosas.png"
    assert abs(r[0]["laikas"] - 0.7) < 0.001


def test_neakcentinis_zodis_lipduko_negauna():
    zodziai = [z("tas", 0.0, 0.2), z("ir", 0.2, 0.4), z("tas", 0.4, 0.6)]
    assert puosyba.parinkti(zodziai, {"ir": "overlays/ir.png"}) == []


def test_dedama_tik_ties_pirmu_pasikartojimu():
    zodziai = [z("KOSMOSAS", 0.0, 0.6), z("vel", 0.6, 0.9), z("KOSMOSAS", 0.9, 1.5)]
    r = puosyba.parinkti(zodziai, {"kosmosas": "overlays/kosmosas.png"})
    assert len(r) == 1
    assert abs(r[0]["laikas"] - 0.0) < 0.001


def test_riba_nukerpa_perteklius():
    zodziai, katalogas = [], {}
    for i in range(9):
        vardas = "ZODIS%d" % i
        zodziai.append(z(vardas, i * 1.0, i * 1.0 + 0.7))
        katalogas[vardas.lower()] = "overlays/%s.png" % vardas.lower()
    r = puosyba.parinkti(zodziai, katalogas)
    assert len(r) == puosyba.PUOSYBOS_RIBA


def test_riba_palieka_anksciausius():
    zodziai, katalogas = [], {}
    for i in range(9):
        vardas = "ZODIS%d" % i
        zodziai.append(z(vardas, i * 1.0, i * 1.0 + 0.7))
        katalogas[vardas.lower()] = "overlays/%s.png" % vardas.lower()
    r = puosyba.parinkti(zodziai, katalogas)
    assert r[0]["laikas"] < r[-1]["laikas"]
    assert r[-1]["laikas"] <= 5.0


def test_tuscias_katalogas_duoda_tuscia_sarasa():
    assert puosyba.parinkti([z("KOSMOSAS", 0.0, 0.6)], {}) == []


def test_katalogas_skaitomas_is_aplanko(tmp_path):
    (tmp_path / "pinigai.png").write_bytes(b"x")
    (tmp_path / "SKAITYK.md").write_text("ne lipdukas")
    k = puosyba.skaityti_katalogas(str(tmp_path))
    assert "pinigai" in k
    assert "skaityk" not in k
