# -*- coding: utf-8 -*-
"""ASS subtitrai @planas_gyvenimas stiliumi.

Trys sriftu vaidmenys viename bloke:
  paprastas  jungiamieji zodziai
  akcentas   minti nesantis zodis (akcento sriftas visada didziosiomis)
  svelnusis  tarpiniai, emociniai zodziai

Spalvos ir sriftai imami is prekes-zenklas.json, todel tas pats skriptas tinka
bet kieno prekes zenklui: keiciamas tik tas failas, ne kodas.

Zodziai atsiranda po viena ir KAUPIASI, kol susidaro blokas, tada blokas keiciamas.
Analize: references/pavyzdziai/reels-planas-gyvenimas/ANALIZE.md
"""
import json, io, os, re, sys

import nustatymai

K = os.path.dirname(os.path.abspath(__file__))
PLOTIS, AUKSTIS = 1080, 1920

# ASS spalva rasoma atbulai ir su permatomumu prieky: &HAABBGGRR.
ZENKLAS  = nustatymai.zenklas()
TEKSTAS  = nustatymai.ass(nustatymai.spalva("tekstas"))
KONTURAS = nustatymai.ass(nustatymai.spalva("konturas"))
ZENKLO_ZODZIU_SPALVA = nustatymai.ass(
    ZENKLAS["spalvos"].get("zenklo_zodziai") or nustatymai.spalva("akcentas"))

# Vaidmenu spalvos. Pakeiciamos is isores, pries kvieciant sukurti().
PAPRASTO_SPALVA = None    # None reiskia zenklo teksto spalva
AKCENTO_SPALVA  = None    # None reiskia zenklo teksto spalva
KURSYVO_SPALVA  = None    # None reiskia zenklo teksto spalva
ZENKLO_SPALVA   = None    # None reiskia zenklo zodziu spalva
KONTURO_SPALVA  = None    # None reiskia zenklo konturo spalva

# Bloko virsus laikomas fiksuotai, blokas auga zemyn.
BLOKO_VIRSUS = 0.52       # dalis kadro aukscio

# Sriftu dydziai
DYDIS_PAPRASTAS = 124
DYDIS_KURSYVAS  = 142
DYDIS_AKCENTAS  = 176     # Bebas Neue, kondensuotas, todel didesnis skaicius
KONTURO_STORIS  = 4

SRIFTAS_PAPRASTAS = nustatymai.sriftas("paprastas")["vardas"]
SRIFTAS_KURSYVAS  = nustatymai.sriftas("kursyvas")["vardas"]
SRIFTAS_AKCENTAS  = nustatymai.sriftas("akcentas")["vardas"]

# Rankinis valdymas. Cia surasomi konkretaus video zodziai.
AKCENTAI = set()          # zodziai, kurie visada akcento sriftu
KURSYVAS = set()          # zodziai, kurie visada kursyvine antikva
# Prekes zenklo zodziai. Rasomi prekes-zenklas.json, ne cia.
PARYSKINTI = {z.lower() for z in ZENKLAS.get("zenklo_zodziai", [])}

# Automatinis kursyvas: trumpi jungiamieji, kurie kuria ritma
KURSYVO_KANDIDATAI = {
    "yra", "bet", "o", "kad", "jau", "gal", "tik", "tiesiog", "labai", "nes",
    "jei", "kai", "tada", "dar", "net", "vis", "taip", "ne", "kaip", "su",
    "is", "iš", "apie", "per", "be", "man", "tau", "sau", "cia", "čia",
}

ZODZIU_BLOKE = 5
BLOKO_TRUKME_MAX = 2.6      # sekundes, kaip etalone
ZODZIU_EILUTEJE_MAX = 3
EILUTES_ZENKLU_BIUDZETAS = 12
TARPAS_NAUJAM_BLOKUI = 0.42


def laikas(s):
    s = max(0.0, s)
    return f"{int(s//3600):d}:{int((s%3600)//60):02d}:{s%60:05.2f}"


def grynas(t):
    return re.sub(r"[^\wąčęėįšųūž]", "",
                  t, flags=re.IGNORECASE).lower()


def skaicius(t):
    return bool(re.search(r"\d", t))


def didziosiomis(t):
    """Saltinyje jau didziosiomis parasytas zodis (REELS, CAPCUT) yra raktinis."""
    raides = re.sub(r"[^\wąčęėįšųūžĄČĘĖĮŠŲŪŽ]", "", t)
    return len(raides) > 1 and raides.isupper()


def grupuoti(zodziai):
    """Skaido zodziu srauta i blokus pagal skyrybos zenklus, pauzes ir ilgi."""
    blokai, dabar = [], []
    for i, z in enumerate(zodziai):
        dabar.append(z)
        pauze = (zodziai[i + 1]["pradzia"] - z["pabaiga"]) if i + 1 < len(zodziai) else 99
        taskas = z["zodis"].rstrip().endswith((".", "!", "?"))
        trukme = z["pabaiga"] - dabar[0]["pradzia"]
        if (taskas or len(dabar) >= ZODZIU_BLOKE or pauze > TARPAS_NAUJAM_BLOKUI
                or trukme >= BLOKO_TRUKME_MAX):
            blokai.append(dabar)
            dabar = []
    if dabar:
        blokai.append(dabar)
    return blokai


def vaidmenys(blokas):
    """Kiekvienam bloko zodziui priskiria vaidmeni: paprastas, akcentas, kursyvas.

    Rankiniai sarasai virsuje turi pirmenybe. Jei bloke nera nurodyto akcento,
    akcentu tampa ilgiausias zodis, o vienas trumpas jungiamasis pasidaro kursyvinis.
    Taip ritmas atsiranda savaime, be rankinio darbo kiekvienam video.
    """
    n = len(blokas)
    v = ["paprastas"] * n
    for i, z in enumerate(blokas):
        g = grynas(z["zodis"])
        if g in PARYSKINTI:
            v[i] = "zenklas"
        elif g in AKCENTAI or skaicius(z["zodis"]) or didziosiomis(z["zodis"]):
            v[i] = "akcentas"
        elif g in KURSYVAS:
            v[i] = "kursyvas"

    laisvi = [i for i in range(n) if v[i] == "paprastas"]

    if not any(x in ("akcentas", "zenklas") for x in v) and laisvi:
        ilgiausias = max(laisvi, key=lambda i: len(grynas(blokas[i]["zodis"])))
        if len(grynas(blokas[ilgiausias]["zodis"])) >= 5:
            v[ilgiausias] = "akcentas"

    if "kursyvas" not in v:
        for i in range(n):
            if v[i] == "paprastas" and grynas(blokas[i]["zodis"]) in KURSYVO_KANDIDATAI:
                v[i] = "kursyvas"
                break
    return v


def eilutes(blokas):
    """Sudeda bloko zodzius i trumpas eilutes, kaip etalone: po du ar tris."""
    eil, dabar, zenklu = [], [], 0
    for i, z in enumerate(blokas):
        ilgis = len(z["zodis"])
        if dabar and (zenklu + ilgis > EILUTES_ZENKLU_BIUDZETAS
                      or len(dabar) >= ZODZIU_EILUTEJE_MAX):
            eil.append(dabar)
            dabar, zenklu = [], 0
        dabar.append(i)
        zenklu += ilgis + 1
    if dabar:
        eil.append(dabar)
    return eil


def zodzio_kodas(tekstas, vaidmuo):
    t = tekstas.replace("{", "").replace("}", "")
    if vaidmuo == "akcentas":
        spalva = AKCENTO_SPALVA or TEKSTAS
        return (r"{\fn%s\i0\fs%d\c%s}" % (SRIFTAS_AKCENTAS, DYDIS_AKCENTAS, spalva)) + t.upper()
    if vaidmuo == "zenklas":
        spalva = ZENKLO_SPALVA or ZENKLO_ZODZIU_SPALVA
        return (r"{\fn%s\i0\fs%d\c%s}" % (SRIFTAS_AKCENTAS, DYDIS_AKCENTAS, spalva)) + t.upper()
    if vaidmuo == "kursyvas":
        spalva = KURSYVO_SPALVA or TEKSTAS
        return (r"{\fn%s\i1\fs%d\c%s}" % (SRIFTAS_KURSYVAS, DYDIS_KURSYVAS, spalva)) + t
    return (r"{\fn%s\i0\fs%d\c%s}" % (SRIFTAS_PAPRASTAS, DYDIS_PAPRASTAS, TEKSTAS)) + t


def ivykiai(blokai):
    """Kaupiamasis atsiradimas: kiekvienam zodziui po ivyki, rodantis viska iki jo."""
    isvestis = []
    for b, blokas in enumerate(blokai):
        v = vaidmenys(blokas)
        eil = eilutes(blokas)
        # Blokas privalo dingti pries prasidedant kitam. Persidengus, libass
        # stumia antra ivyki zemyn ir tekstas nusleidzia i kadro apacia.
        kitas = blokai[b + 1][0]["pradzia"] if b + 1 < len(blokai) else None
        for k in range(len(blokas)):
            pr = blokas[k]["pradzia"]
            if k + 1 < len(blokas):
                pb = blokas[k + 1]["pradzia"]
            else:
                pb = blokas[k]["pabaiga"] + 0.34
                if kitas is not None:
                    pb = min(pb, kitas - 0.02)
            # Minimali trukme galioja tik paskutiniam bloko zodziui. Bloko viduje
            # pb jau yra kito zodzio pradzia, ir ja pastumus ivykiai persidengia,
            # o libass tada nustumia teksta i kadro apacia.
            if pb - pr < 0.06 and k + 1 >= len(blokas):
                pb = pr + 0.06

            dalys = []
            for e in eil:
                matomi = [i for i in e if i <= k]
                if not matomi:
                    break
                dalys.append(" ".join(zodzio_kodas(blokas[i]["zodis"], v[i]) for i in matomi))
            tekstas = r"\N".join(dalys)

            atsiradimas = r"{\fad(70,0)}" if k == 0 else ""
            isvestis.append(
                f"Dialogue: 0,{laikas(pr)},{laikas(pb)},Kalba,,0,0,0,,{atsiradimas}{tekstas}")
    return isvestis


def sukurti(zodziu_failas, isvestis):
    zodziai = [z for z in json.load(io.open(zodziu_failas, encoding="utf-8")) if z["zodis"].strip()]
    marginv = int(AUKSTIS * BLOKO_VIRSUS)
    pagrindine = PAPRASTO_SPALVA or TEKSTAS
    # Konturas laiko teksta skaitoma ant bet kokio fono. Alfa pridedama priekyje.
    pagrindas = (KONTURO_SPALVA or KONTURAS)[4:]
    konturas, sesely = "&H30" + pagrindas, "&H90" + pagrindas
    galva = f"""[Script Info]
ScriptType: v4.00+
PlayResX: {PLOTIS}
PlayResY: {AUKSTIS}
WrapStyle: 2
ScaledBorderAndShadow: yes

[V4+ Styles]
Format: Name, Fontname, Fontsize, PrimaryColour, SecondaryColour, OutlineColour, BackColour, Bold, Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, Angle, BorderStyle, Outline, Shadow, Alignment, MarginL, MarginR, MarginV, Encoding
Style: Kalba,{SRIFTAS_PAPRASTAS},{DYDIS_PAPRASTAS},{pagrindine},{pagrindine},{konturas},{sesely},0,0,0,0,100,100,1,0,1,{KONTURO_STORIS},4,8,80,80,{marginv},204

[Events]
Format: Layer, Start, End, Style, Name, MarginL, MarginR, MarginV, Effect, Text
"""
    blokai = grupuoti(zodziai)
    io.open(isvestis, "w", encoding="utf-8").write(galva + "\n".join(ivykiai(blokai)) + "\n")
    print(f"Subtitrai: {os.path.basename(isvestis)} | zodziu {len(zodziai)}, bloku {len(blokai)}")
    for b in blokai:
        v = vaidmenys(b)
        zenklai = {"paprastas": "", "akcentas": "*", "kursyvas": "~", "zenklas": "#"}
        print(f"   {b[0]['pradzia']:5.2f}  " +
              " ".join(zenklai[v[i]] + z["zodis"] for i, z in enumerate(b)))


if __name__ == "__main__":
    # Be argumentu: zodziai-galutiniai.json -> subtitrai.ass (tai, ko laukia montazas.py)
    ivestis = sys.argv[1] if len(sys.argv) > 1 else "zodziai-galutiniai.json"
    isvestis = sys.argv[2] if len(sys.argv) > 2 else "subtitrai.ass"
    sukurti(os.path.join(K, ivestis), os.path.join(K, isvestis))
