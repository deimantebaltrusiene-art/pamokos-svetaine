"""Garso efektai Reels perejimams. Generuojami kodu, jokiu isoriniu bibliotekos failu."""
import numpy as np, wave, os, sys

DR = 48000
ISVESTIS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "garsai")
os.makedirs(ISVESTIS, exist_ok=True)

def irasyti(vardas, x):
    x = np.clip(x, -1, 1)
    duomenys = (x * 32767).astype(np.int16)
    with wave.open(os.path.join(ISVESTIS, vardas), "w") as f:
        f.setnchannels(1); f.setsampwidth(2); f.setframerate(DR)
        f.writeframes(duomenys.tobytes())
    print(f"  {vardas}  {len(x)/DR:.2f} s")

def vokas(n, ataka, gesimas, galia=2.0):
    a = max(1, int(ataka * DR)); g = max(1, int(gesimas * DR))
    v = np.ones(n)
    v[:a] = np.linspace(0, 1, a) ** 0.5
    v[-g:] = np.linspace(1, 0, g) ** galia
    return v

def vienpolis_filtras(x, kirtis):
    """Paprastas zemu daznio filtras, kai kirtis kinta laike."""
    y = np.zeros_like(x); b = 0.0
    a = np.exp(-2 * np.pi * kirtis / DR)
    for i in range(len(x)):
        b = (1 - a[i]) * x[i] + a[i] * b
        y[i] = b
    return y

rng = np.random.default_rng(7)

# 1. Whoosh: triuksmas per kylanti ir krintanti filtra, imituoja prasilekianti kadra
n = int(0.42 * DR); t = np.linspace(0, 1, n)
triuksmas = rng.normal(0, 1, n)
kirtis = 300 + 6500 * np.sin(np.pi * t) ** 1.6
w = vienpolis_filtras(triuksmas, kirtis)
w = w / (np.max(np.abs(w)) + 1e-9)
w *= vokas(n, 0.03, 0.22, 2.4) * 0.55
irasyti("whoosh.wav", w)

# 2. Pop: trumpas krintantis tonas robotuko pasirodymui
n = int(0.16 * DR); t = np.linspace(0, 0.16, n)
f = 880 * np.exp(-6 * t) + 180
p = np.sin(2 * np.pi * np.cumsum(f) / DR)
p += 0.3 * np.sin(4 * np.pi * np.cumsum(f) / DR)
p *= vokas(n, 0.004, 0.13, 3.0) * 0.45
irasyti("pop.wav", p)

# 3. Klik: sausas akcentas teksto pasikeitimui
n = int(0.07 * DR); t = np.linspace(0, 0.07, n)
k = rng.normal(0, 1, n) * np.exp(-55 * t)
k = vienpolis_filtras(k, np.full(n, 4200.0))
k = k / (np.max(np.abs(k)) + 1e-9) * 0.3
irasyti("klik.wav", k)

# 4. Riser: kylantis tonas pries kirti
n = int(0.55 * DR); t = np.linspace(0, 1, n)
f = 220 * (1 + 5.5 * t ** 2)
r = np.sin(2 * np.pi * np.cumsum(f) / DR) * 0.25
r += vienpolis_filtras(rng.normal(0, 1, n), 500 + 5000 * t) * 0.25
r *= (t ** 1.5) * vokas(n, 0.05, 0.05, 1.0) * 0.6
irasyti("riser.wav", r)

# 5. Pustelejimas: svelnus oro gustelejimas minkstam perejimui.
# Zemesnis ir tylesnis uz whoosh, kad persiliejimo nepaverstu smugiu.
n = int(0.38 * DR); t = np.linspace(0, 1, n)
kirtis = 200 + 900 * np.sin(np.pi * t) ** 1.2
pu = vienpolis_filtras(rng.normal(0, 1, n), kirtis)
pu = pu / (np.max(np.abs(pu)) + 1e-9)
pu *= vokas(n, 0.10, 0.20, 2.0) * 0.35
irasyti("pustelejimas.wav", pu)

print("Garsai paruosti:", ISVESTIS)
