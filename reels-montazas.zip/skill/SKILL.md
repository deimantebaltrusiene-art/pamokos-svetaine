---
name: reels-montazas
description: Sumontuoti Reels iš telefono video vietiniais įrankiais be jokių kreditų: tylų iškirpimas, transkripcija, subtitrai trimis šriftais, kadravimas pagal veidą, priartėjimo kirtimai, ženkliukai, garso efektai ir patikra po renderio. Naudoti, kai prašoma „sumontuok Reels", „padaryk Reels iš šito video", „uždėk subtitrus", „iškirpk tylas", „perdaryk montažą", arba tiesiog atsiunčiamas .mov failas iš telefono. Taip pat naudoti, kai mokymų dalyvis stato tą pačią sistemą savo kompiuteryje.
---

# Reels montažas

Visa Reels gamyba vyksta tame kompiuteryje, kuriame paleidžiama. Jokių kreditų,
jokio įkėlimo į svetimus serverius, interneto reikia tik pirmą kartą
parsisiunčiant modelį.

Įrankiai guli `tools/reels-montazas/`. Ten pat `README.md` su visais parametrais,
spąstais ir paaiškinimais, kodėl kas padaryta būtent taip.

> **Prieš pradedant perskaityk `tools/reels-montazas/README.md`.** Šitas failas
> sako, ką daryti ir kokia tvarka. README sako, kokius skaičius rašyti ir kur
> slypi spąstai. Be jo montažas pavyks, bet kokybė bus prastesnė.

## Kai aktyvuoti

- „sumontuok Reels", „padaryk Reels iš šito video"
- „uždėk subtitrus", „iškirpk tylas", „perdaryk montažą"
- Atsiunčiamas `.mov` arba `.mp4` iš telefono ir norima paruošto vertikalaus video
- Mokymų dalyvis nori tos pačios sistemos savo kompiuteryje

## Ko nesiūlyti

Nesiūlyti CapCut, Captions, Opus Clip ar kitų įrankių. Jie čia nereikalingi ir
kainuoja. Viskas padaroma vietoje.

## Pirmas žingsnis visada

```
PYTHONIOENCODING=utf-8 python nustatymai.py
```

Parodo, kurį ffmpeg, kurį šaltinio video ir kurį prekės ženklo failą sistema
mato. Nieko nekeičia. Jei kas nors rodo „NERASTA“, taisyti reikia ten, ne kode.

## Eiga

| Žingsnis | Skriptas | Ką daro |
|---|---|---|
| 0. Kur karpyti | `tylos.py` | Randa pauzes ir pasiūlo segmentus. Nieko nekeičia |
| 1. Garsas | `ffmpeg` | Ištraukia `garsas.wav`, 16 kHz, mono |
| 2. Transkripcija | `transkribuoti.py large-v3` | Žodžiai su laikais į `zodziai-large-v3.json` |
| 3. Iškirpimai | `paruosti_zodzius.py` | Išmeta iškirptus žodžius, perskaičiuoja laikus |
| 4. Subtitrai | `subtitrai.py` | ASS failas su kaupiamuoju atsiradimu |
| 5. Kadravimas | `veido_sekimas.py` | Randa akis, sugeneruoja `virsus.json` |
| 6. Montažas | `montazas.py` | Surenka viską į `reels.mp4`. Segmentai rašomi tik čia |
| 7. Patikra | `patikra.py reels.mp4` | Technika, spalvos, subtitrų persidengimai |

**Windows visada su `PYTHONIOENCODING=utf-8`.** Be jo skriptai lūžta ties lietuviškomis raidėmis.

## Prekės ženklas gyvena JSON faile, ne kode

`tools/reels-montazas/prekes-zenklas.json` laiko spalvas, šriftus, ženklo
žodžius, užrašo tekstą ir transkripcijos žodyną. Kode nėra nė vienos įrašytos
spalvos ir nė vieno šrifto pavadinimo, todėl tie patys skriptai tinka bet kam.

Kuriant Reels kitam žmogui arba kitam prekės ženklui keičiamas tik tas failas.
Nieko nerašyti tiesiai į `subtitrai.py`, `orbita.py` ar `uzrasas.py`.

## Kur reikia žmogaus akių

Trys vietos, kur skriptas pasiūlo, o sprendžia žmogus. Parodyk variantą ir palauk:

1. **Kur karpyti.** `tylos.py` pasiūlo segmentus pagal pauzes. Numatyta riba 0,80 s.
   Riba 0,32 išmeta ir įkvėpimus, bet kalba tampa kapota. **Prieš rodydamas pasiūlymą
   sulygink jį su žodžių laikais transkripcijoje:** segmentas turi prasidėti ne vėliau už
   pirmo žodžio pradžią ir baigtis ne anksčiau už paskutinio žodžio pabaigą. Tyliai
   pradėtas žodis tylų paieškai atrodo kaip tyla ir nukerpamas.
2. **Kurie žodžiai akcentai.** `subtitrai.py` vaidmenis priskiria pats, bet mintį
   nešantį žodį geriau pasirinkti ranka per `AKCENTAI` ir `KURSYVAS`.
3. **Ar liesti spalvas.** Keturi jungikliai `montazas.py` viršuje numatytai išjungti.
   Be prašymo neįjungti.

## Kas keičiama rankomis prieš renderį

`montazas.py` viršuje:

- `VIDEO_SEGMENTAI` — `(pradžia, pabaiga, priartėjimas)` šaltinio laikais
- `GARSO_SEGMENTAI` — kurie garso gabalai lieka
- `ZENKLIUKAS_1`, `ZENKLIUKAS_2`, `ROBOTUKAS` — kada pasirodo ženkliukai
- `GRADAVIMAS`, `TRIUKSMO_VALYMAS`, `ASTRINIMAS`, `PROZEKTORIUS` — apdorojimas

Šaltinio kelio rašyti nereikia: imamas naujausias video iš `ivestis/`. Kitą failą
galima nurodyti per `REELS_SALTINIS`.

## Visada

- **Renderį paleisk fone.** Jis trunka minutes, o pokalbis tuo metu gali eiti toliau.
- **Po renderio paleisk `patikra.py`.** Ji pagauna tris dalykus, kurių akis nemato:
  išplautas spalvas, persidengusius subtitrus ir garso lubas.
- **Rezultatą atidaryk pats** grotuve, nelaukdamas prašymo: Windows `cmd //c start reels.mp4`, Mac `open reels.mp4`
- **Senos versijos į `archyvas/`,** niekada netrinti.

## Mokymų dalyviams

Sistema nepririšta prie vieno kompiuterio. Dalyvio žingsniai:

1. `pip install faster-whisper imageio-ffmpeg opencv-python pillow`
2. Video į `ivestis/`
3. `prekes-zenklas.pavyzdys.json` kopija pavadinimu `prekes-zenklas.json`, į ją
   surašomos savo spalvos, šriftai ir žodžiai. Jeigu dalyvis turi savo stiliaus
   failą, imk spalvas iš jo ir užpildyk už jį, paskui parodyk, ką įrašei.
4. `python nustatymai.py` — patikrinti, ar viskas randama
5. Toliau eiga kaip lentelėje

Nieko iš to nekeičiama kode. Jeigu tenka rašyti kelią ar spalvą į `.py` failą,
kažkas pamiršta ir tai reikia taisyti `nustatymai.py` arba `prekes-zenklas.json`.
