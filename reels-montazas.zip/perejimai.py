# -*- coding: utf-8 -*-
"""Perejimu katalogas. Kiekvienas perejimas yra vaizdo efektas ir jam pritaikytas garsas.

Vaizdo dalis remiasi dviem mechanizmais, kurie montazas.py jau veikia:
  priartejimas  segmento lygyje (kaip VIDEO_SEGMENTAI treciasis skaicius)
  suliejimas    trumpas langas po sujungimo, ties kirtimo laiku

Etalonas: references/pavyzdziai/reels-planas-gyvenimas/ANALIZE.md
Ten devyni is desimties perejimu yra paprastas kirtis, todel kirtis cia numatytasis.
"""

ILGOS_PAUZES_RIBA = 0.45   # sekundes, nuo kiek pauze laikoma nauja mintimi
GARSUMO_LUBOS = 0.68       # ties tiek efektas dar girdisi po loudnorm balsu

PEREJIMAI = {
    "kirtis":    {"garsas": None,           "garsumas": 0.00,
                  "priartejimas": 1.00, "suliejimas": 0.00},
    "smugis":    {"garsas": "whoosh",       "garsumas": 0.55,
                  "priartejimas": 1.00, "suliejimas": 0.25},
    "minkstas":  {"garsas": "pustelejimas", "garsumas": 0.35,
                  "priartejimas": 1.00, "suliejimas": 0.40},
    "taskas":    {"garsas": "pop",          "garsumas": 0.50,
                  "priartejimas": 1.06, "suliejimas": 0.00},
    "ikvepimas": {"garsas": "riser",        "garsumas": 0.45,
                  # atitolinti zemiau 1.00 negalima, nes scale plius crop
                  # konvejeris neturi is ko iskirpti; ikvepimas skiriasi
                  # garsu (riser) ir suliejimu (0.30), ne priartejimu
                  "priartejimas": 1.00, "suliejimas": 0.30},
}


def parinkti(pauzes):
    """Kiekvienam segmentui parenka perejima pagal pauze pries ji ir vieta scenarijuje.

    pauzes: sarasas float, pauzes ilgis pries kiekviena segmenta. Pirmas visada 0.
    Grazina sarasa vardu, po viena kiekvienam segmentui.

    Taisykles, nuo svarbiausios:
      pirmas segmentas              kirtis      i ji einama is nuotraukos
      paskutinis segmentas          taskas      isvada
      priespaskutinis segmentas     ikvepimas   ikvepimas pries pabaiga
      pauze nuo ILGOS_PAUZES_RIBA   smugis      nauja mintis
      visa kita                     kirtis      numatytasis
    """
    n = len(pauzes)
    vardai = []
    for i, pauze in enumerate(pauzes):
        if i == 0:
            vardai.append("kirtis")
        elif i == n - 1:
            vardai.append("taskas")
        elif i == n - 2 and n >= 4:
            vardai.append("ikvepimas")
        elif pauze >= ILGOS_PAUZES_RIBA:
            vardai.append("smugis")
        else:
            vardai.append("kirtis")
    return vardai
