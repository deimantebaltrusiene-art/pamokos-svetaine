# -*- coding: utf-8 -*-
"""3D orbita su technologiju terminais, sukanti aplink zmogu kadre.

Tikras trimatis skaiciavimas, ne pieste elipse. Kiekvienas tasko gylis (z) lemia
dydi, ryskuma ir linijos stori, todel uzpakaline ziedo puse atrodo nutolusi, o
priekine artima, ir orbita skaitoma kaip erdvine, nors zmogus kadre nesegmentuotas.

Paletė paimta is „Antrosios desiniosios rankos“ vizualo
(projects/wow-3d-vizualas/vizualas.html): neonine zalia virsuje, tamsi misko zemai,
oranzinis akcentas ties pusiauju. Del to abu darbai atrodo kaip vienas prekes zenklas.

Isvestis: PNG seka su permatomu fonu, kuria montazas uzdeda ant video.
"""
import math, os, sys
from PIL import Image, ImageDraw, ImageFont, ImageFilter

import nustatymai

K = os.path.dirname(os.path.abspath(__file__))
PLOTIS, AUKSTIS, KADRAI = 1080, 1920, 30
SS = 2                                   # supersamplingas, kad linijos butu lygios

CENTRAS = (0.50, 0.35)                   # dalimis nuo kadro, ties galva ir peciais
FOKUSAS = 1500.0                         # perspektyvos stiprumas

# Paletė imama is prekes-zenklas.json. Nenurodzius savo ziedu spalvu, jos
# gaminamos is antros zenklo spalvos: sviesesne virsuje, tamsesne zemai.
_z = nustatymai.orbitos_spalvos()
ZIEDO_SVIESI = nustatymai.rgb(_z[0])
ZIEDO_VIDURI = nustatymai.rgb(_z[1])
ZIEDO_TAMSI  = nustatymai.rgb(_z[2])
AKCENTAS     = nustatymai.rgb(nustatymai.spalva("akcentas"))
TEKSTAS      = nustatymai.rgb(nustatymai.spalva("tekstas"))
FONAS        = nustatymai.rgb(nustatymai.spalva("fonas"))

SRIFTAS = nustatymai.sriftas("storas")["kelias"]

# Ziedai: (spindulys, posvyris, pasukimas, greitis aps/s, pradinis kampas)
# Greiciai perpus letesni uz pirmaji varianta: orbita turi kvepuoti, ne skubeti.
ZIEDAI = [
    (430, 34, -18,  0.072, 0.0),
    (368, 55,  34, -0.094, 1.9),
    (306, 28, -52,  0.118, 3.6),
    (244, 62,  72, -0.140, 5.1),
]

# Terminai ziedams. Pirmas skaicius yra ziedo numeris, antras vieta ant ziedo.
# Terminai. Savus galima surasyti prekes-zenklas.json lauke „orbitos_terminai“
# kaip [ziedo numeris, vieta ant ziedo, zodis]; tada sis sarasas nenaudojamas.
TERMINAI = [
    (0, 0.00, "Python"),
    (0, 0.26, "Playwright"),
    (0, 0.52, "API keys"),
    (0, 0.76, "webhook"),
    (1, 0.10, "MCP"),
    (1, 0.38, "tokens"),
    (1, 0.63, "promptai"),
    (1, 0.86, "agentai"),
    (2, 0.16, "ffmpeg"),
    (2, 0.46, "git"),
    (2, 0.72, "skriptai"),
    (3, 0.30, "JSON"),
    (3, 0.68, "CLI"),
]

_savi = nustatymai.zenklas().get("orbitos_terminai") or []
if _savi:
    TERMINAI = [tuple(t) for t in _savi]

# Veido zona: cia terminai prislopinami, kad neuzdengtu veido.
VEIDO_ZONA = (0.50, 0.33, 0.26, 0.20)    # centras x, y ir spinduliai, dalimis nuo kadro

DALELES = 64                             # smulkios zvaigzdutes tarp ziedu
VINJETES_STIPRIS = 0.78                  # kiek patamsinami kadro krastai
PULSO_GREITIS = 0.32                     # zodziu didejimo ir mazejimo daznis, Hz
PULSO_GYLIS = 0.22                       # kiek zodis isauga ir susitraukia


def taskas(R, teta, posvyris, pasukimas):
    """Tasko ant ziedo ekrano koordinates ir gylis.

    Ziedas guli XZ plokstumoje, pasukamas apie X asi (posvyris), tada apie
    zvilgsnio asi (pasukimas). Grazina (x, y, z, mastelis).
    """
    t = math.radians(posvyris)
    r = math.radians(pasukimas)
    x = R * math.cos(teta)
    y = -R * math.sin(teta) * math.sin(t)
    z = R * math.sin(teta) * math.cos(t)
    xr = x * math.cos(r) - y * math.sin(r)
    yr = x * math.sin(r) + y * math.cos(r)
    mastelis = FOKUSAS / (FOKUSAS - z)
    return xr * mastelis, yr * mastelis, z, mastelis


def gylio_dalis(z, R):
    """Nuo 0 (toliausiai) iki 1 (arciausiai). Nuo jos priklauso ryskumas ir storis."""
    return max(0.0, min(1.0, (z / R + 1.0) / 2.0))


def maisyti(a, b, dalis):
    dalis = max(0.0, min(1.0, dalis))
    return tuple(int(round(a[i] + (b[i] - a[i]) * dalis)) for i in range(3))


def ziedo_spalva(y_santykis, g):
    """Spalva pagal auksti ziede ir gyli.

    Virsuje neonine zalia, zemai tamsi misko, o ties pusiauju iseina oranzinis
    akcentas. Tokia pati logika kaip „Antrosios desiniosios rankos“ sferoje.
    """
    if y_santykis <= 0:
        spalva = maisyti(ZIEDO_VIDURI, ZIEDO_SVIESI, -y_santykis)
    else:
        spalva = maisyti(ZIEDO_VIDURI, ZIEDO_TAMSI, y_santykis)
    # Pusiaujas yra ten, kur |y| mazas. Ten idedamas oranzinis akcentas.
    pusiaujas = max(0.0, 1.0 - abs(y_santykis) * 3.2)
    spalva = maisyti(spalva, AKCENTAS, pusiaujas * 0.75)
    return maisyti(maisyti(spalva, FONAS, 0.45), spalva, g)


_vinjete = None


def vinjete(W, H):
    """Tamsus radialinis gradientas kadro krastuose, skaiciuojamas viena karta.

    Neonine zalia ant sviesiu uzuolaidu nesvyti: sviesus fonas nustelbia svytejima.
    Patamsinus krastus, orbita atgauna kontrasta, o veidas centre lieka nepaliestas.
    """
    global _vinjete
    if _vinjete is not None and _vinjete.size == (W, H):
        return _vinjete
    m = 96
    kauke = Image.new("L", (m, int(m * H / W)))
    px = kauke.load()
    for y in range(kauke.height):
        for x in range(m):
            nx = (x / (m - 1) - 0.5) * 2.0
            ny = (y / (kauke.height - 1) - 0.42) * 1.7
            r = min(1.0, math.hypot(nx, ny) / 1.25)
            px[x, y] = int(255 * VINJETES_STIPRIS * (r ** 2.1))
    kauke = kauke.resize((W, H), Image.BICUBIC)
    sluoksnis = Image.new("RGBA", (W, H), FONAS + (0,))
    sluoksnis.putalpha(kauke)
    _vinjete = sluoksnis
    return sluoksnis


def piesti_kadra(t, trukme):
    """Vienas orbitos kadras laiku t. Grazina RGBA paveiksla.

    Piesiama i du sluoksnius: svytejimo ir rysku. Svytejimas suliejamas ir
    padedamas apacioje, todel linijos bei zodziai atrodo sviesus, o ne pliki.
    """
    W, H = PLOTIS * SS, AUKSTIS * SS
    svytis = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    rysku = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    ds = ImageDraw.Draw(svytis)
    dr = ImageDraw.Draw(rysku)
    cx, cy = CENTRAS[0] * W, CENTRAS[1] * H

    # Bendras isejimas ir isnykimas, kad orbita neatsirastu ir nedingtu staiga
    if t < 0.55:
        bendra = (t / 0.55) ** 0.7
    elif t > trukme - 0.45:
        bendra = max(0.0, (trukme - t) / 0.45)
    else:
        bendra = 1.0
    if bendra <= 0.001:
        return Image.new("RGBA", (PLOTIS, AUKSTIS), (0, 0, 0, 0))

    # Orbita issiskleidzia is centro, o ne tiesiog issirysketa
    isskleidimas = 0.62 + 0.38 * min(1.0, (t / 0.85) ** 0.6)

    for R, posvyris, pasukimas, greitis, pradzia in ZIEDAI:
        Rs = R * SS * isskleidimas
        faze = pradzia + 2 * math.pi * greitis * t
        SEGMENTU = 200
        for i in range(SEGMENTU):
            a1 = faze + 2 * math.pi * i / SEGMENTU
            a2 = faze + 2 * math.pi * (i + 1) / SEGMENTU
            x1, y1, z1, _ = taskas(Rs, a1, posvyris, pasukimas)
            x2, y2, z2, _ = taskas(Rs, a2, posvyris, pasukimas)
            g = gylio_dalis((z1 + z2) / 2, Rs)
            alfa = int(255 * bendra * (0.34 + 0.66 * g ** 1.15))
            if alfa <= 2:
                continue
            storis = max(2, int(round(SS * (1.9 + 4.4 * g ** 2))))
            spalva = ziedo_spalva((y1 + y2) / 2 / Rs, g)
            linija = [cx + x1, cy + y1, cx + x2, cy + y2]
            dr.line(linija, fill=spalva + (alfa,), width=storis)
            ds.line(linija, fill=spalva + (alfa,), width=storis * 4)

    # Daleles tarp ziedu, kad erdve neatrodytu tuscia
    for i in range(DALELES):
        R, posvyris, pasukimas, greitis, pradzia = ZIEDAI[i % len(ZIEDAI)]
        Rs = R * SS * isskleidimas * (0.76 + 0.32 * ((i * 37) % 11) / 10.0)
        a = pradzia + 2 * math.pi * (greitis * 0.7 * t + i / DALELES)
        x, y, z, _ = taskas(Rs, a, posvyris, pasukimas)
        g = gylio_dalis(z, Rs)
        alfa = int(255 * bendra * (0.06 + 0.60 * g ** 2))
        if alfa <= 2:
            continue
        r = SS * (1.4 + 3.4 * g ** 2)
        spalva = maisyti(ZIEDO_SVIESI, TEKSTAS, g * 0.45)
        dr.ellipse([cx + x - r, cy + y - r, cx + x + r, cy + y + r], fill=spalva + (alfa,))
        ds.ellipse([cx + x - r * 3, cy + y - r * 3, cx + x + r * 3, cy + y + r * 3],
                   fill=spalva + (int(alfa * 0.5),))

    # Terminai. Tekstas visada statmenas, sukasi tik jo vieta, dydis ir ryskumas.
    for zi, vieta, tekstas in TERMINAI:
        R, posvyris, pasukimas, greitis, pradzia = ZIEDAI[zi]
        Rs = R * SS * isskleidimas
        a = pradzia + 2 * math.pi * (greitis * t + vieta)
        x, y, z, mastelis = taskas(Rs, a, posvyris, pasukimas)
        g = gylio_dalis(z, Rs)

        # Terminas, uzejes ant veido, prislopinamas. Ties zonos krastu tolygiai
        # atgauna ryskuma, todel dingimas nepastebimas.
        vx, vy, vrx, vry = VEIDO_ZONA
        nx = (cx + x - vx * W) / (vrx * W)
        ny = (cy + y - vy * H) / (vry * H)
        nuotolis = math.hypot(nx, ny)
        slopinimas = min(1.0, max(0.06, nuotolis ** 2.0)) if nuotolis < 1.0 else 1.0
        alfa = int(255 * bendra * (0.30 + 0.70 * g ** 1.6) * slopinimas)
        if alfa <= 6:
            continue

        # Pulsas: zodis tai isauga, tai susitraukia, nepriklausomai nuo perspektyvos
        pulsas = 1.0 + PULSO_GYLIS * math.sin(2 * math.pi * (PULSO_GREITIS * t + vieta))
        dydis = max(8, int(round(SS * 46 * (0.68 + 0.52 * g) * mastelis ** 0.5 * pulsas)))
        sriftas = ImageFont.truetype(SRIFTAS, dydis)
        # Spalva pagal ziedą, ne pagal gylį: taip zalia ir oranzine lieka aiskios
        pagrindine = AKCENTAS if zi % 2 else ZIEDO_SVIESI
        spalva = maisyti(maisyti(pagrindine, FONAS, 0.30), pagrindine, g)
        plotis_t = dr.textlength(tekstas, font=sriftas)
        px, py = cx + x - plotis_t / 2, cy + y - dydis * 0.62

        # Prie kadro krasto terminas issikvepia, o ne buna nukerpamas per puse.
        # Nukirptas zodis skaitomas kaip klaida, isnykes atrodo kaip orbitos eiga.
        atsarga = dydis * 1.6
        istrauka = min(px, W - (px + plotis_t))
        if istrauka < 0:
            continue
        if istrauka < atsarga:
            alfa = int(alfa * (istrauka / atsarga))
            if alfa <= 6:
                continue

        # Tamsi kapsule po tekstu. Be jos zodis dingsta ant sviesaus fono.
        pad_x, pad_y = dydis * 0.42, dydis * 0.26
        r = (dydis + 2 * pad_y) / 2
        dezute = [px - pad_x, py - pad_y, px + plotis_t + pad_x, py + dydis + pad_y]
        dr.rounded_rectangle(dezute, radius=r, fill=FONAS + (int(alfa * 0.82),))
        dr.text((px, py), tekstas, font=sriftas, fill=spalva + (alfa,))
        ds.rounded_rectangle(dezute, radius=r, outline=spalva + (int(alfa * 0.8),),
                             width=max(2, int(SS * 2.4)))

    svytis = svytis.filter(ImageFilter.GaussianBlur(radius=SS * 9))
    fonas = vinjete(W, H)
    if bendra < 1.0:
        fonas = fonas.copy()
        fonas.putalpha(fonas.getchannel("A").point(lambda a: int(a * bendra)))
    kadras = Image.alpha_composite(fonas, svytis)
    return Image.alpha_composite(kadras, rysku).resize((PLOTIS, AUKSTIS), Image.LANCZOS)


def sukurti(trukme, aplankas):
    os.makedirs(aplankas, exist_ok=True)
    for f in os.listdir(aplankas):
        if f.endswith(".png"):
            os.remove(os.path.join(aplankas, f))
    n = int(round(trukme * KADRAI))
    for i in range(n):
        piesti_kadra(i / KADRAI, trukme).save(os.path.join(aplankas, f"o_{i:04d}.png"))
        if i % 20 == 0:
            print(f"  kadras {i}/{n}", flush=True)
    print(f"Orbita: {n} kadru -> {aplankas}")
    return n


if __name__ == "__main__":
    trukme = float(sys.argv[1]) if len(sys.argv) > 1 else 3.54
    sukurti(trukme, os.path.join(K, "orbita"))
