# -*- coding: utf-8 -*-
"""Randa ramiausia laisva plota kadre lipdukui uzdeti.

Dvi draudziamos sritys ir vienas kriterijus: maziausia sviesumo dispersija.
Maza dispersija reiskia lygia siena, ne rankas ar rasta, todel lipdukas ten neskesta.
Sritys nurodomos dalimis (x1, y1, x2, y2) nuo 0 iki 1.
"""
import numpy as np

VEIDO_ZONA     = (0.20, 0.00, 0.80, 0.45)
SUBTITRU_ZONA  = (0.00, 0.48, 1.00, 0.80)
LANGELIS = 120          # taskai, tinklelio zingsnis
PAKRASTYS = 40          # taskai, atstumas nuo kadro krasto


def _kertasi(x, y, w, h, zona, plotis, aukstis):
    zx1, zy1, zx2, zy2 = zona
    return (x < zx2 * plotis and x + w > zx1 * plotis
            and y < zy2 * aukstis and y + h > zy1 * aukstis)


def rasti(kadras, lipduko_plotis, lipduko_aukstis):
    """Grazina (x, y) ramiausiam leistinam langeliui arba None, jei tokio nera.

    kadras: 2D numpy masyvas su sviesumo reiksmemis (aukstis, plotis).
    """
    aukstis, plotis = kadras.shape[:2]
    if lipduko_plotis > plotis or lipduko_aukstis > aukstis:
        return None

    geriausia, geriausia_verte = None, None
    for y in range(PAKRASTYS, aukstis - lipduko_aukstis - PAKRASTYS + 1, LANGELIS):
        for x in range(PAKRASTYS, plotis - lipduko_plotis - PAKRASTYS + 1, LANGELIS):
            if _kertasi(x, y, lipduko_plotis, lipduko_aukstis,
                        VEIDO_ZONA, plotis, aukstis):
                continue
            if _kertasi(x, y, lipduko_plotis, lipduko_aukstis,
                        SUBTITRU_ZONA, plotis, aukstis):
                continue
            sritis = kadras[y:y + lipduko_aukstis, x:x + lipduko_plotis]
            verte = float(np.var(sritis))
            if geriausia_verte is None or verte < geriausia_verte:
                geriausia, geriausia_verte = (x, y), verte
    return geriausia
