# -*- coding: utf-8 -*-
"""Prekes zenklo uzrasas kaip permatomas PNG, kuri montazas uzdeda ant video.

Tamsi kapsule po tekstu yra butina, ne puosybine: kadro fonas yra sviesios
uzuolaidos, ir oranzinis tekstas ant ju dingsta. Ta pati kapsule vartojama ir
orbitos terminams, todel abu sluoksniai atrodo kaip viena sistema.
"""
import os
from PIL import Image, ImageDraw, ImageFont

import nustatymai

K = os.path.dirname(os.path.abspath(__file__))
PLOTIS, AUKSTIS = 1080, 1920
SS = 2

# Spalvos, sriftai ir pats tekstas imami is prekes-zenklas.json.
AKCENTAS = nustatymai.rgb(nustatymai.zenklas()["spalvos"].get("zenklo_zodziai")
                          or nustatymai.spalva("akcentas"))
SVIESI   = nustatymai.rgb(nustatymai.spalva("tekstas"))
TAMSI    = nustatymai.rgb(nustatymai.spalva("fonas"))

BEBAS = nustatymai.sriftas("akcentas")["kelias"]
LATO  = nustatymai.sriftas("storas")["kelias"]

TEKSTAS   = nustatymai.zenklas()["uzrasas"]["tekstas"]
PASTRAIPA = nustatymai.zenklas()["uzrasas"]["pastraipa"]
DYDIS = 152
DYDIS_MAZAS = 44
CENTRAS_Y = 0.165           # dalis kadro aukscio


def sukurti(isvestis):
    if not TEKSTAS:
        raise SystemExit("Uzraso tekstas tuscias. Irasyk ji prekes-zenklas.json "
                         "lauke uzrasas.tekstas")
    W, H = PLOTIS * SS, AUKSTIS * SS
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)

    f_did = ImageFont.truetype(BEBAS, DYDIS * SS)
    f_maz = ImageFont.truetype(LATO, DYDIS_MAZAS * SS)

    w_did = d.textlength(TEKSTAS, font=f_did)
    w_maz = d.textlength(PASTRAIPA, font=f_maz)

    pad_x, pad_y = 52 * SS, 30 * SS
    tarpas = 16 * SS
    vidus_a = DYDIS * SS * 0.80 + tarpas + DYDIS_MAZAS * SS
    kapsules_p = max(w_did, w_maz) + 2 * pad_x
    kapsules_a = vidus_a + 2 * pad_y

    x0 = (W - kapsules_p) / 2
    y0 = CENTRAS_Y * H - kapsules_a / 2

    d.rounded_rectangle([x0, y0, x0 + kapsules_p, y0 + kapsules_a],
                        radius=34 * SS, fill=TAMSI + (232,))

    # Bebas Neue turi tuscia tarpa virs raidziu, todel tekstas keliamas aukstyn
    d.text(((W - w_did) / 2, y0 + pad_y - DYDIS * SS * 0.22),
           TEKSTAS, font=f_did, fill=AKCENTAS + (255,))
    d.text(((W - w_maz) / 2, y0 + pad_y + DYDIS * SS * 0.80 + tarpas),
           PASTRAIPA, font=f_maz, fill=SVIESI + (208,))

    im.resize((PLOTIS, AUKSTIS), Image.LANCZOS).save(isvestis)
    print(f"Uzrasas: {os.path.basename(isvestis)}")


if __name__ == "__main__":
    sukurti(os.path.join(K, "uzrasas.png"))
