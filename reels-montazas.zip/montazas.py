# -*- coding: utf-8 -*-
"""Reels: nuotraukos atidarymas, priartejimo kirtimai, zenkliukai, subtitrai, garsai."""
import io, json, os, subprocess, sys
import nustatymai
import perejimai

K = os.path.dirname(os.path.abspath(__file__))

# Nieko prirakinto prie vieno kompiuterio: ffmpeg randamas savaime, o saltinis
# imamas is ivestis/ arba is REELS_SALTINIS. Konkretu faila galima nurodyti ir
# cia, tada jis nugali: SALTINIS = r"C:\kelias\video.mov"
FF = nustatymai.ffmpeg()
SALTINIS = nustatymai.saltinis()

PLOTIS, AUKSTIS, KADRAI = 1080, 1920, 30
VIRSUS = 0.30                 # bendras kadro nuleidimas, jei atskiru nera

# Atskiras VIRSUS kiekvienam segmentui, kad veidas visur sedetu vienodai.
# Reiksmes gamina veido_sekimas.py ir sudeda i virsus.json; jei tas failas
# yra, jis naudojamas savaime. Norint grizti prie rankinio kadravimo,
# uztenka istrinti virsus.json. Cia irasytas sarasas nugali abu.
VIRSUS_SEGMENTAI = None

# Vaizdo apdorojimas. Isjungus visus keturis, saltinio spalvos lieka nepaliestos.
GRADAVIMAS      = False   # kontrastas ir spalvingumas
TRIUKSMO_VALYMAS = False  # hqdn3d
ASTRINIMAS      = 0.0     # 0 = isjungta, tinkama reiksme apie 0.55
PROZEKTORIUS    = False   # veidas sviesesnis, aplinka tamsesne

# Prozektorius: veidas sviesesnis, aplinka tamsesne (kauke.png)
APLINKA_TAMSIAU = 0.05
APLINKA_SPALVA  = 0.93
VEIDAS_SVIESIAU = 0.035
VEIDAS_GAMA     = 1.055

FOTO_TRUKME = 1.30                       # kol skamba "Claude Code"
VIDEO_SEGMENTAI = [                      # (pradzia, pabaiga, priartejimas) saltinio laikais
    (2.46,  6.68, 1.00),
    (6.68,  9.12, 1.10),
    (9.12, 11.56, 1.00),
    (11.56, 16.12, 1.07),
    (16.12, 20.85, 1.00),
    (21.90, 23.60, 1.18),                # "kosmosas" su stipriu priartejimu
]
GARSO_SEGMENTAI = [(1.16, 20.85), (21.90, 23.60)]

ZENKLIUKAS_1 = (0.30, 1.30)              # Claude zvaigzdute ant nuotraukos
ZENKLIUKAS_2 = (9.55, 11.40)             # ties "uzdeda subtitrus"
ROBOTUKAS    = (15.75, 19.60)            # ties "uzdeda stikerius"

# Nebutini priedai. Jei failo nera, montazas eina be jo: be nuotraukos pradzioje,
# be zenkliuku, be robotuko, be prozektoriaus. Naujam zmogui nieko nereikia trinti
# ar perrasyti. Laikas None isjungia ta prieda ir tada, kai failas yra.
NUOTRAUKA        = "nuotrauka.png"
ZENKLIUKO_FAILAS = "zenkliukas.png"
ROBOTUKO_FAILAS  = "robotukas-svarus.png"
KAUKE            = "kauke.png"


def yra(failas):
    return os.path.exists(os.path.join(K, failas))


def priedai():
    """Kurie nebutini priedai siandien dalyvauja montaze."""
    return {
        "nuotrauka": yra(NUOTRAUKA) and FOTO_TRUKME > 0,
        "zenkliukas_1": yra(NUOTRAUKA) and FOTO_TRUKME > 0 and yra(ZENKLIUKO_FAILAS) and ZENKLIUKAS_1 is not None,
        "zenkliukas_2": yra(ZENKLIUKO_FAILAS) and ZENKLIUKAS_2 is not None,
        "robotukas": yra(ROBOTUKO_FAILAS) and ROBOTUKAS is not None,
        "kauke": yra(KAUKE),
    }


def foto_trukme():
    """Nuotraukos atidarymo trukme; 0, jei nuotraukos nera."""
    return FOTO_TRUKME if priedai()["nuotrauka"] else 0.0

def saltinio_diapazonas():
    """Ar saltinis pilno (pc), ar standartinio (tv) diapazono.

    Suspausti i tv galima tik pilno diapazono saltini. Suspaudus jau suspausta,
    dingsta kontrastas ir spalvos. Butent tai ir buvo klaida.
    """
    r = subprocess.run([FF, "-hide_banner", "-i", SALTINIS], capture_output=True, text=True)
    eilutes = [x for x in r.stderr.splitlines() if "Video:" in x]
    tekstas = eilutes[0] if eilutes else ""
    return "pc" if ("yuvj" in tekstas or "(pc," in tekstas) else "tv"


def virsaus_sarasas():
    """Kiekvieno segmento VIRSUS. Rankinis sarasas, tada virsus.json, tada bendras."""
    if VIRSUS_SEGMENTAI:
        sarasas, is_kur = list(VIRSUS_SEGMENTAI), "VIRSUS_SEGMENTAI"
    else:
        kelias = os.path.join(K, "virsus.json")
        if not os.path.exists(kelias):
            return [VIRSUS] * len(VIDEO_SEGMENTAI), f"bendras VIRSUS={VIRSUS}"
        with io.open(kelias, encoding="utf-8") as f:
            sarasas, is_kur = json.load(f)["virsus"], "virsus.json"
    if len(sarasas) != len(VIDEO_SEGMENTAI):
        print(f"DEMESIO: {is_kur} turi {len(sarasas)} reiksmiu, o segmentu "
              f"{len(VIDEO_SEGMENTAI)}. Griztama prie bendro VIRSUS={VIRSUS}.")
        return [VIRSUS] * len(VIDEO_SEGMENTAI), f"bendras VIRSUS={VIRSUS}"
    return sarasas, is_kur


def segmentu_pauzes():
    """Pauze pries kiekviena segmenta saltinio laiku. Pirmam segmentui visada 0."""
    pauzes = [0.0]
    for i in range(1, len(VIDEO_SEGMENTAI)):
        pauzes.append(VIDEO_SEGMENTAI[i][0] - VIDEO_SEGMENTAI[i - 1][1])
    return pauzes


def kirtimu_laikai():
    """Kiekvieno segmento pradzios laikas isvesties laiko juostoje.

    kirtimu_laikai()[j] yra segmento j pradzia, tai yra kirtimo i ji laikas.
    """
    laikai, praejo = [], foto_trukme()
    laikai.append(praejo)
    for a, b, _ in VIDEO_SEGMENTAI[:-1]:
        praejo += b - a
        laikai.append(praejo)
    return laikai


def statyti(isvestis):
    nustatymai.reikia_saltinio(SALTINIS)
    nustatymai.paruosti_sriftus()
    diapazonas = saltinio_diapazonas()
    kirtimai = kirtimu_laikai()
    print("Saltinio diapazonas:", diapazonas,
          "(bus pertvarkytas)" if diapazonas == "pc" else "(paliekamas kaip yra)")
    yra_ = priedai()
    prozektorius = PROZEKTORIUS and yra_["kauke"]
    if PROZEKTORIUS and not prozektorius:
        print("Prozektorius isjungtas: nera", KAUKE)
    print("Priedai:", ", ".join(k for k, v in yra_.items() if v) or "jokiu")

    # ffmpeg ivestys; idx saugo, kelinta yra kiekviena
    ivestys, idx = [], {}
    def prideti(vardas, *argai):
        idx[vardas] = len(idx)
        ivestys.extend(argai)
    prideti("saltinis", "-i", SALTINIS)
    if yra_["nuotrauka"]:
        prideti("nuotrauka", "-loop", "1", "-framerate", str(KADRAI), "-t", f"{FOTO_TRUKME}", "-i", NUOTRAUKA)
    if yra_["zenkliukas_1"] or yra_["zenkliukas_2"]:
        prideti("zenkliukas", "-i", ZENKLIUKO_FAILAS)
    if yra_["robotukas"]:
        prideti("robotukas", "-i", ROBOTUKO_FAILAS)
    for garsas in ("whoosh", "pop", "riser"):
        prideti(garsas, "-i", os.path.join("garsai", garsas + ".wav"))
    if yra_["kauke"]:
        prideti("kauke", "-loop", "1", "-framerate", str(KADRAI), "-t", "24", "-i", KAUKE)
    prideti("pustelejimas", "-i", os.path.join("garsai", "pustelejimas.wav"))

    f = []
    foto_kadrai = int(FOTO_TRUKME * KADRAI)
    if yra_["nuotrauka"]:
        f.append(
        f"[{idx['nuotrauka']}:v]zoompan=z='1+0.11*on/{foto_kadrai-1}':x='iw/2-(iw/zoom/2)':y='ih/2-(ih/zoom/2)'"
        f":d=1:s={PLOTIS}x{AUKSTIS}:fps={KADRAI},trim=end_frame={foto_kadrai},setpts=PTS-STARTPTS,"
        f"setsar=1[v0]"
        )
    # Prozektorius uzdedamas viena karta ant viso saltinio, pries karpant
    pries = []
    if TRIUKSMO_VALYMAS:
        pries.append("hqdn3d=1.2:1.0:5:5")
    if GRADAVIMAS:
        pries.append("eq=contrast=1.05:saturation=1.08:brightness=0.010")
    grandine = ("[0:v]" + ",".join(pries) + "," if pries else "[0:v]")

    if prozektorius:
        f.append(grandine + "format=gbrp,split=2[sv_t][sv_s]")
        f.append(f"[sv_t]eq=brightness=-{APLINKA_TAMSIAU}:saturation={APLINKA_SPALVA}[aplinka]")
        f.append(f"[sv_s]eq=brightness={VEIDAS_SVIESIAU}:gamma={VEIDAS_GAMA}[veidas]")
        f.append(f"[{idx['kauke']}:v]format=gbrp[kauke]")
        f.append("[aplinka][veidas][kauke]maskedmerge,format=yuv420p,"
                 f"split={len(VIDEO_SEGMENTAI)}"
                 + "".join(f"[s{i}]" for i in range(1, len(VIDEO_SEGMENTAI) + 1)))
    else:
        f.append(grandine + f"format=yuv420p,split={len(VIDEO_SEGMENTAI)}"
                 + "".join(f"[s{i}]" for i in range(1, len(VIDEO_SEGMENTAI) + 1)))

    vardai = perejimai.parinkti(segmentu_pauzes())
    print("Perejimai:", vardai)
    virsus, is_kur = virsaus_sarasas()
    print("Kadro nuleidimas:", [round(v, 3) for v in virsus], f"({is_kur})")

    for i, (a, b, z) in enumerate(VIDEO_SEGMENTAI, start=1):
        # crop visada PLOTIS x AUKSTIS, todel z negali nukristi zemiau 1.0
        # (zemiau to scale butu mazesnis uz crop ir ffmpeg klaidu "Invalid too big size").
        # Tai apsauginis tinklas, ne kasdienis kelias: kataloge (perejimai.py) joks
        # priartejimas nera mazesnis uz 1.00, tai garantuoja testas
        # test_priartejimas_niekada_nemazesnis_uz_viena.
        z = max(1.0, z * perejimai.PEREJIMAI[vardai[i - 1]]["priartejimas"])
        w, h = int(PLOTIS * z) // 2 * 2, int(AUKSTIS * z) // 2 * 2
        f.append(
            f"[s{i}]trim=start={a:.3f}:end={b:.3f},setpts=PTS-STARTPTS,"
            f"scale={w}:{h}:force_original_aspect_ratio=increase:flags=lanczos,"
            f"crop={PLOTIS}:{AUKSTIS}:(iw-{PLOTIS})/2:(ih-{AUKSTIS})*{virsus[i-1]},"
            + (f"unsharp=5:5:{ASTRINIMAS}:5:5:0.0," if ASTRINIMAS > 0 else "")
            + f"setsar=1[v{i}]"
        )
    pirmas = 0 if yra_["nuotrauka"] else 1
    f.append("".join(f"[v{i}]" for i in range(pirmas, len(VIDEO_SEGMENTAI) + 1))
             + f"concat=n={len(VIDEO_SEGMENTAI) + 1 - pirmas}:v=1:a=0[vs]")
    f.append(f"[vs]fps={KADRAI},format=yuva420p[baze]")

    # Perejimu suliejimas: trumpas gblur langas ties kiekvieno kirtimo laiku
    langai = []
    for i, vardas in enumerate(vardai):
        trukme = perejimai.PEREJIMAI[vardas]["suliejimas"]
        if trukme <= 0:
            continue
        t = kirtimai[i]        # kirtimai[i] yra segmento i pradzia
        langai.append("gblur=sigma=18:enable='between(t,%.3f,%.3f)'"
                      % (t - trukme / 2, t + trukme / 2))
    if langai:
        f.append("[baze]" + ",".join(langai) + "[baze_p]")
        BAZE = "[baze_p]"
    else:
        BAZE = "[baze]"

    # Zenkliukai: iseina su nedideliu atsoklu, tada tyliai supasi
    if yra_["zenkliukas_1"]:
        f.append(f"[{idx['zenkliukas']}:v]scale=210:-1[zn1]")
    if yra_["zenkliukas_2"]:
        f.append(f"[{idx['zenkliukas']}:v]scale=190:-1[zn2]")
    if yra_["robotukas"]:
        f.append(f"[{idx['robotukas']}:v]scale=300:-1[rob]")

    virsutinis = BAZE
    if yra_["zenkliukas_1"]:
        t = ZENKLIUKAS_1[0]
        f.append(f"{virsutinis}[zn1]overlay=x='70':y='{140}-40*max(0,1-(t-{t})/0.30)':"
                 f"enable='between(t,{ZENKLIUKAS_1[0]},{ZENKLIUKAS_1[1]})'[o1]")
        virsutinis = "[o1]"
    if yra_["zenkliukas_2"]:
        t = ZENKLIUKAS_2[0]
        f.append(f"{virsutinis}[zn2]overlay=x='min(80,-200+280*(t-{t})/0.30)':y='700+12*sin(2*PI*(t-{t})*1.2)':"
                 f"enable='between(t,{ZENKLIUKAS_2[0]},{ZENKLIUKAS_2[1]})'[o2]")
        virsutinis = "[o2]"
    if yra_["robotukas"]:
        t = ROBOTUKAS[0]
        f.append(f"{virsutinis}[rob]overlay=x='min(60,-320+380*(t-{t})/0.32)':y='620+18*sin(2*PI*(t-{t})*1.1)':"
                 f"enable='between(t,{ROBOTUKAS[0]},{ROBOTUKAS[1]})'[o3]")
        virsutinis = "[o3]"

    pabaiga = ("scale=in_range=pc:out_range=tv," if diapazonas == "pc" else "") + "format=yuv420p"
    f.append(f"{virsutinis}subtitles=subtitrai.ass:fontsdir=fonts,{pabaiga}[vaizdas]")

    # Garsas
    for j, (a, b) in enumerate(GARSO_SEGMENTAI):
        f.append(f"[0:a]atrim=start={a:.3f}:end={b:.3f},asetpts=PTS-STARTPTS[g{j}]")
    f.append("".join(f"[g{j}]" for j in range(len(GARSO_SEGMENTAI)))
             + f"concat=n={len(GARSO_SEGMENTAI)}:v=0:a=1[gs]")
    f.append("[gs]highpass=f=90,acompressor=threshold=0.09:ratio=3:attack=8:release=180,"
             "loudnorm=I=-14:TP=-1.5:LRA=11[balsas]")

    efektai = []
    for i, vardas in enumerate(vardai):
        p = perejimai.PEREJIMAI[vardas]
        if not p["garsas"]:
            continue
        ms = int(max(0.0, kirtimai[i] - 0.06) * 1000)
        f.append("[%d:a]adelay=%d|%d,volume=%.2f[pe%d]"
                 % (idx[p["garsas"]], ms, ms, p["garsumas"], i))
        efektai.append("[pe%d]" % i)
    popai = ([ZENKLIUKAS_2[0]] if yra_["zenkliukas_2"] else []) + ([ROBOTUKAS[0]] if yra_["robotukas"] else [])
    for j, tk in enumerate(popai):
        ms = int(tk * 1000)
        f.append(f"[{idx['pop']}:a]adelay={ms}|{ms},volume=0.6[pp{j}]")
        efektai.append(f"[pp{j}]")
    if yra_["nuotrauka"]:
        ms = int(max(0.0, FOTO_TRUKME - 0.55) * 1000)
        f.append(f"[{idx['riser']}:a]adelay={ms}|{ms},volume=0.5[riseris]")
        efektai.append("[riseris]")

    f.append("[balsas]" + "".join(efektai)
             + f"amix=inputs={len(efektai)+1}:duration=first:normalize=0,alimiter=limit=0.95[garsas]")

    komanda = [
        FF, "-y", "-hide_banner", "-loglevel", "error", "-stats",
        *ivestys,
        "-filter_complex", ";".join(f),
        "-map", "[vaizdas]", "-map", "[garsas]",
        "-c:v", "libx264", "-preset", "slow", "-crf", "17", "-x264-params", "aq-mode=3:psy-rd=1.0,0.15",
        "-pix_fmt", "yuv420p", "-profile:v", "high", "-level", "4.0",
        "-movflags", "+faststart", "-color_range", "tv", "-r", str(KADRAI),
        "-c:a", "aac", "-b:a", "192k", "-ar", "48000",
        isvestis,
    ]
    trukme = foto_trukme() + sum(b - a for a, b, _ in VIDEO_SEGMENTAI)
    print("Kirtimai:", [round(x, 2) for x in kirtimai], "| trukme", round(trukme, 2), "s")
    r = subprocess.run(komanda, cwd=K)
    print("Gatava:", isvestis) if r.returncode == 0 else print("KLAIDA", r.returncode)
    return r.returncode

if __name__ == "__main__":
    sys.exit(statyti(sys.argv[1] if len(sys.argv) > 1 else "reels.mp4"))
