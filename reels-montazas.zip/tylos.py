# -*- coding: utf-8 -*-
"""Randa tylas ir mikciojimo pauzes ir pasiulo, kur karpyti.

Nieko nekeicia. Tik parodo sarasa ir isspausdina paruostus iklijuoti
GARSO_SEGMENTAI ir VIDEO_SEGMENTAI, kuriuos anksciau rinkdavai ranka.
Sprendima priimi tu: pazvelgi i sarasa ir arba iklijuoji, arba pataisai.

Naudojimas:
    PYTHONIOENCODING=utf-8 python tylos.py                  saltinis is montazas.py
    PYTHONIOENCODING=utf-8 python tylos.py kelias/video.mov  kitas failas
    PYTHONIOENCODING=utf-8 python tylos.py . 0.32            smulkus karpymas

Antras argumentas yra trumpiausia pauze sekundemis. Taskas vietoj kelio
reiskia "imk saltini is montazas.py".

    0.80  numatyta. Ismeta tik stambias pauzes, kalba lieka rissli. Siame
          video duoda beveik tiksliai ta pati, ka rinkaisi ranka.
    0.32  jumpcut. Ismeta ir ikvepimus, video tampa greitas ir kapotas.

Jei per daug karpo, kelk skaiciu arba mazink TYLOS_RIBA_DB (pvz. -38).
"""
import os, re, subprocess, sys

import montazas

K = os.path.dirname(os.path.abspath(__file__))

TYLOS_RIBA_DB = -32.0   # kas tyliau uz sia riba, laikoma tyla
MIN_TYLA = 0.80         # trumpesniu pauziu neliesti, kitaip kalba tampa kapota
ATSARGA = 0.10          # kiek sekundziu palikti aplink kalba, kad nenukastu galu
MIN_SEGMENTAS = 0.40    # uz si trumpesniu likuciu nelaikyti atskiru segmentu


def trukme(kelias):
    r = subprocess.run([montazas.FF, "-hide_banner", "-i", kelias],
                       capture_output=True, text=True)
    m = re.search(r"Duration:\s*(\d+):(\d+):([\d.]+)", r.stderr)
    if not m:
        raise SystemExit("Nepavyko nuskaityti trukmes")
    return int(m.group(1)) * 3600 + int(m.group(2)) * 60 + float(m.group(3))


def rasti_tylas(kelias):
    """Tylos intervalai is ffmpeg silencedetect."""
    r = subprocess.run(
        [montazas.FF, "-hide_banner", "-nostats", "-i", kelias,
         "-af", f"silencedetect=noise={TYLOS_RIBA_DB}dB:d={MIN_TYLA}",
         "-f", "null", "-"],
        capture_output=True, text=True,
    )
    tylos, pradzia = [], None
    for eilute in r.stderr.splitlines():
        m = re.search(r"silence_start:\s*(-?[\d.]+)", eilute)
        if m:
            pradzia = float(m.group(1))
            continue
        m = re.search(r"silence_end:\s*([\d.]+)", eilute)
        if m and pradzia is not None:
            tylos.append((max(0.0, pradzia), float(m.group(1))))
            pradzia = None
    if pradzia is not None:
        tylos.append((max(0.0, pradzia), None))     # tyla iki pat galo
    return tylos


def kalbos_segmentai(tylos, visa):
    """Tai, kas lieka isemus tylas, su atsarga aplink kalba."""
    segmentai, zymeklis = [], 0.0
    for a, b in tylos:
        a = min(visa, a + ATSARGA)                  # tyla prasideda kiek veliau
        if a - zymeklis >= MIN_SEGMENTAS:
            segmentai.append((round(zymeklis, 2), round(a, 2)))
        if b is None:
            return segmentai
        zymeklis = max(0.0, b - ATSARGA)            # ir baigiasi kiek anksciau
    if visa - zymeklis >= MIN_SEGMENTAS:
        segmentai.append((round(zymeklis, 2), round(visa, 2)))
    return segmentai


def main():
    global MIN_TYLA
    kelias = sys.argv[1] if len(sys.argv) > 1 and sys.argv[1] != "." else montazas.SALTINIS
    if len(sys.argv) > 2:
        MIN_TYLA = float(sys.argv[2])
    if not os.path.exists(kelias):
        raise SystemExit(f"Nera failo: {kelias}")
    visa = trukme(kelias)
    print(f"Saltinis: {os.path.basename(kelias)}  |  trukme {visa:.2f} s")
    print(f"Riba {TYLOS_RIBA_DB} dB, trumpiausia pauze {MIN_TYLA} s, atsarga {ATSARGA} s")
    print()

    tylos = rasti_tylas(kelias)
    if not tylos:
        print("Tylu nerasta. Arba video svarus, arba riba per zema.")
        return 0

    print("Rastos tylos (siulomos ismesti):")
    ismesta = 0.0
    for a, b in tylos:
        if b is None:
            print(f"  {a:6.2f} -> galas          uodega")
            ismesta += visa - a
        else:
            print(f"  {a:6.2f} -> {b:6.2f}     {b - a:5.2f} s")
            ismesta += b - a
    print(f"\nIs viso tyliose vietose {ismesta:.2f} s is {visa:.2f} s")

    segmentai = kalbos_segmentai(tylos, visa)
    if not segmentai:
        print("Po karpymo neliktu nieko. Riba per aukstas, sumazink TYLOS_RIBA_DB.")
        return 1
    liks = sum(b - a for a, b in segmentai)
    print(f"Po karpymo liktu {liks:.2f} s, tai yra {visa - liks:.2f} s trumpiau\n")

    print("Iklijuoti i montazas.py (paruosti_zodzius.py pasiima is ten):")
    print("GARSO_SEGMENTAI = [" + ", ".join(f"({a:.2f}, {b:.2f})" for a, b in segmentai) + "]")
    print()
    print("Iklijuoti i montazas.py (priartejimai visur 1.00, pasirink pats):")
    print("VIDEO_SEGMENTAI = [")
    for a, b in segmentai:
        print(f"    ({a:5.2f}, {b:5.2f}, 1.00),")
    print("]")
    print()
    print("Nieko nepakeista. Perziurek sarasa ir iklijuok tik tai, kam pritari.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
