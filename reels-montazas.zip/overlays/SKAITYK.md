# Lipdukai

Meta čia PNG failus su permatomu fonu.

**Failo vardas yra žodis, prie kurio lipdukas rišamas.** Pavyzdžiui `pinigai.png`
atsiras tada, kai įraše bus ištartas žodis „pinigai".

Du ribojimai, kad lipdukai nešokinėtų be reikalo:

- dedama tik ties **pirmu** to žodžio pasikartojimu,
- dedama tik jei tas žodis yra **akcentinis** (tas pats sprendimas, kurį daro `subtitrai.py`).

Vienam Reels dedama ne daugiau kaip **šeši** puošybos elementai.
