# Reels montažas

Reels gamyba iš telefono video: transkripcija, subtitrai, priartėjimo kirtimai,
robotukas, garso efektai. Viskas vietoje, 0 kreditų, be interneto (išskyrus
vienkartinį modelio parsisiuntimą).

## Nustatymai: kompiuteris ir prekės ženklas

Viskas, kas vienam žmogui skiriasi nuo kito, guli dviejose vietose, ir nė viena
iš jų nėra kodas.

**`nustatymai.py`** pats randa, ko reikia:

| Kas | Kaip randama |
|---|---|
| ffmpeg | `REELS_FFMPEG`, paskui `imageio-ffmpeg`, paskui `PATH` |
| šaltinio video | `REELS_SALTINIS`, paskui naujausias failas iš `ivestis/` |
| prekės ženklas | `REELS_ZENKLAS`, paskui `prekes-zenklas.json` šalia skriptų |

Pasitikrinti galima vienu paleidimu, jis nieko nekeičia:

```
PYTHONIOENCODING=utf-8 python nustatymai.py
```

**`prekes-zenklas.json`** laiko spalvas, šriftus ir žodžius. Kode nebėra nė
vienos įrašytos spalvos ir nė vieno šrifto pavadinimo:

| Laukas | Kur matosi |
|---|---|
| `spalvos.tekstas` | subtitrų rašalas |
| `spalvos.akcentas` | orbitos pusiaujas, užrašas |
| `spalvos.zenklo_zodziai` | žodžiai iš `zenklo_zodziai` sąrašo |
| `spalvos.fonas` | kapsulė po užrašu, orbitos gylis |
| `spalvos.antra` | orbitos žiedai, jei nenurodytos `orbitos_spalvos` |
| `sriftai.paprastas/akcentas/kursyvas/storas` | trys subtitrų vaidmenys ir užrašas |
| `zenklo_zodziai` | kurie žodžiai subtitruose visada akcento spalva |
| `uzrasas.tekstas`, `uzrasas.pastraipa` | `uzrasas.py` gaminamas PNG |
| `transkripcijos_zodynas` | ką modeliui pasakyti prieš klausantis |

Nurodyti reikia ne visko. Ko faile nėra, imama iš neutralių numatytųjų: balta
rašė, gintarinis akcentas, kartu gulintys šriftai. Naujas žmogus pradeda nuo
`prekes-zenklas.pavyzdys.json` kopijos.

Šriftai imami iš `fonts/`, iš sistemos šriftų arba iš pilno kelio. Svetur gulintį
šriftą montažas prieš renderį pats nusikopijuoja į `fonts/`, nes libass ten
žiūri. Nerastas šriftas darbo nenutraukia: paimamas atsarginis ir parašoma, kas
nutiko.

## Ko reikia

- `faster-whisper` (įdiegta 2026-08-18): `pip install faster-whisper`
- ffmpeg ateina su `imageio-ffmpeg`, sistemoje atskirai diegti nereikia
- Modelis **large-v3**. „medium“ lietuvių kalbai per silpnas: vardus ir „Claude Code“
  nugirsta neteisingai.
- Veido aptikimui `modeliai/yunet.onnx` (233 KB, guli repozitorijoje). Nieko diegti
  nereikia: `cv2` jau yra, o **mediapipe NEREIKIA**. Jis šitame kompiuteryje
  užsitemptų `opencv-contrib-python 5.0` ir pakeistų veikiantį `cv2 4.13`.

## Eiga

0. **Kur karpyti** (nebūtina, bet greitina). `tylos.py` randa pauzes ir pasiūlo
   `GARSO_SEGMENTAI` bei `VIDEO_SEGMENTAI`. Nieko nekeičia, tik parodo sąrašą.

   ```
   PYTHONIOENCODING=utf-8 python tylos.py
   PYTHONIOENCODING=utf-8 python tylos.py . 0.32     smulkus, jumpcut stiliaus
   ```

   Numatyta trumpiausia pauzė 0,80 s. Ties šia riba antrame darbe skriptas pasiūlė
   `1,95–20,63`, o ranka buvo pasirinkta `1,16–20,85`. Riba 0,32 išmeta ir įkvėpimus,
   bet kalba tampa kapota.

1. **Garsas iš video**

   ```
   ffmpeg -i saltinis.mov -map 0:a:0 -ac 1 -ar 16000 -c:a pcm_s16le garsas.wav
   ```

2. **Transkripcija** (Windows būtinai su `PYTHONIOENCODING=utf-8`, kitaip lūžta ties „ą“)

   ```
   PYTHONIOENCODING=utf-8 python transkribuoti.py large-v3
   ```

   Modeliui prieš klausantis pakišamas žodynas iš `prekes-zenklas.json` lauko
   `transkripcijos_zodynas`: vardai, produktai, įrankiai. Be jo modelis šiuos
   žodžius iškraipo.

3. **Iškirpimai ir laikų perskaičiavimas.** `paruosti_zodzius.py` segmentus pasiima iš
   `montazas.py` (`GARSO_SEGMENTAI` gyvena tik ten), o viršuje laiko transkripcijos taisymus. Skriptas išmeta iškirptus
   žodžius ir perskaičiuoja likusių laikus į naują laiko juostą.

4. **Subtitrai.** `python subtitrai.py` (be argumentų: `zodziai-galutiniai.json` → `subtitrai.ass`) padaro ASS failą su kaupiamaisiais subtitrais. Spalvos ir šriftai imami
   iš `prekes-zenklas.json`, o patys šriftų failai iš `fonts/`, nes sistemoje jų gali nebūti.

   **Kaupiamasis atsiradimas.** Žodžiai atsiranda po vieną ir lieka ekrane, kol susidaro
   bloko iki penkių žodžių, tada blokas keičiamas. Ne „aktyvus žodis šviečia“, o augantis
   blokas.

   **Trys šriftų vaidmenys viename bloke:**

   | Vaidmuo | Šriftas | Kam |
   |---|---|---|
   | paprastas | `sriftai.paprastas`, 124 | jungiamieji žodžiai |
   | akcentas | `sriftai.akcentas`, 176 | mintį nešantis žodis, visada didžiosiomis |
   | švelnusis | `sriftai.kursyvas`, 142 | tarpiniai, emociniai žodžiai |
   | ženklas | `sriftai.akcentas`, ženklo spalva | žodžiai iš `zenklo_zodziai` |

   Vaidmenys priskiriami savaime: skaičius arba didžiosiomis parašytas žodis tampa akcentu,
   ilgiausias žodis tampa akcentu, jei bloke nė vieno nėra, o vienas trumpas jungiamasis
   tampa kursyviniu. Norint valdyti rankomis, failo viršuje yra `AKCENTAI` ir `KURSYVAS`.

   Blokas laikomas ties `BLOKO_VIRSUS = 0.52` kadro aukščio ir auga žemyn.

5. **Kadravimas pagal veidą** (nebūtina). `veido_sekimas.py` randa akis kiekviename
   segmente ir apskaičiuoja, kiek nuleisti kadrą, kad veidas visur sėdėtų vienodai.

   ```
   PYTHONIOENCODING=utf-8 python veido_sekimas.py
   ```

   Rezultatas gula į `virsus.json`, o `montazas.py` jį pasiima pats. Peržiūrai lieka
   `_veido_sekimas.png`: oranžinis stačiakampis yra būsimas kadras, žalias yra veidas,
   žalia linija yra akys, oranžinė linija yra tikslas. Norint grįžti prie rankinio
   kadravimo, užtenka ištrinti `virsus.json`.

6. **Montažas.** `montazas.py` viršuje surašomi tie patys segmentai su priartėjimais.
   Kiekvienas segmentas kadruojamas atskirai, todėl perėjimas tarp jų atrodo kaip kirtis.

7. **Patikra po renderio.** `patikra.py` patikrina keturis dalykus ir duoda verdiktą.

   ```
   PYTHONIOENCODING=utf-8 python patikra.py reels.mp4
   ```

   Tikrina techniką (trukmė, matmenys, garso lubos), spalvas (šaltinis apkarpomas
   lygiai taip pat, bet be apdorojimo, ir lyginami vidurkiai), ASS įvykių
   persidengimus ir padaro kadrų juostą `_patikra.png`.

## Ką verta žinoti

- **Garso efektai gaminami kodu** (`garsai.py`): whoosh, pop, klik, riser. Jokių
  parsisiųstų bibliotekų.
- **Kadravimas keliamas aukštyn** (`VIRSUS = 0.30`), nes selfio kadre veidas viršuje.
  Centruojant priartinimą veidas nukerpamas.
- **Robotuko permatomi taškai nudažomi oranžine** prieš mažinant, kitaip lieka baltas
  šešėlis aplink ženkliuką.
- **Subtitrų blokai negali persidengti laike.** Persidengus dviem ASS įvykiams, libass
  antrąjį nustumia žemyn ir tekstas nušoka į kadro apačią. Todėl paskutinio bloko žodžio
  uodega apkarpoma prieš kito bloko pradžią.
- **Playfair Display imamas iš `google/fonts` GitHub, ne iš Google Fonts API.** API atiduoda
  apkarpytą šriftą be lietuviškų raidžių. Patikrinta: apkarpytame trūko visų ą č ę ė į š ų ū ž.
- **Spalvų diapazonas.** iPhone duoda `yuvj420p` (pilnas). Neperkeltas į `tv` diapazoną,
  Instagram perkoduodamas pakeičia kontrastą. Todėl grandinės gale
  `scale=in_range=pc:out_range=tv` ir `-color_range tv`.
- Likusi Windows suderinamumo dalis kaip visada: `yuv420p`, `profile high`, `level 4.0`,
  `+faststart`, garsas AAC.

## Nuotraukos atidarymas

`montazas.py` pirmas segmentas gali būti nuotrauka su lėtu priartėjimu. Naudinga, kai
kalbant ištariamas žodis, kurį nuotrauka parodo (pavyzdžiui, plakatas su „CLAUDE CODE“).
Garsas tuo metu ateina iš video, o vaizdas iš nuotraukos.

Nuotrauka nebūtina. Jei `nuotrauka.png` nėra, montažas prasideda iškart nuo video, o
nuotraukos riseris praleidžiamas.

**Spąstas:** `-loop 1` duoda begalinį nuotraukos srautą, o `zoompan` su `d=N` gamina po
N kadrų kiekvienam įvesties kadrui. Kartu tai niekada nesibaigia ir renderis pakimba.
Teisingai: įvestį riboti laike (`-loop 1 -framerate 30 -t 1.30`), o `zoompan` naudoti su
`d=1` ir priartėjimą skaičiuoti nuo `on`.

## Žodžių paryškinimas

`prekes-zenklas.json` sąraše `zenklo_zodziai` surašomi žodžiai, kurie visada rodomi
ženklo spalva ir didesni. Aktyvus žodis paryškinamas papildomai. Kode jų nebėra:
`subtitrai.py` sąrašą `PARYSKINTI` susideda pats iš to failo.

**Spąstas:** `WrapStyle: 2` draudžia automatinį eilučių kėlimą, todėl ilga eilutė
išlipa už ekrano. Reikia `WrapStyle: 0`.

## Ženkliukai

- `robotukas-svarus.png` — robotukas su permatomu fonu
- `zenkliukas.png` — Claude žvaigždutė apvaliais kampais su šešėliu

Abu nebūtini: jei failo nėra arba laikas `None`, ženkliukas ir jo `pop` praleidžiami.
Tas pats su `kauke.png` prožektoriui. Tai saugo `tests/test_montazas_priedai.py`.

Dedami į tuščią kadro pusę. Selfio kadre veidas paprastai vienoje pusėje, tad ženkliukai
eina į kitą. Kiekvienas ženkliukas gauna savo `pop` garsą.

## Prožektorius (veidas šviesesnis, aplinka tamsesnė)

`kauke.png` yra minkšta pilka kaukė: šviesi elipsė ten, kur žmogus, juoda aplinkui,
stipriai suliejta. `montazas.py` iš šaltinio pasidaro dvi versijas, vieną patamsintą,
kitą pašviesintą, ir sulieja jas per kaukę (`maskedmerge`). Stiprumas keičiamas
keturiais kintamaisiais faile: `APLINKA_TAMSIAU`, `APLINKA_SPALVA`, `VEIDAS_SVIESIAU`,
`VEIDAS_GAMA`.

**Kodėl ne `vignette`.** Įprastas ffmpeg vinjetės filtras kampuose palieka juodas dėmes
ir atrodo grubiai. Kaukė su `maskedmerge` krenta tolygiai ir leidžia atskirai valdyti,
kiek keliamas veidas ir kiek leidžiama aplinka.

**Svarbu.** Prožektorius dedamas ant šaltinio prieš karpant, todėl jis seka kadravimą.
Nuotraukos segmentas jo negauna sąmoningai: nuotraukoje svarbus objektas dažnai būna
viršuje (plakatas), o kaukė viršų patamsintų.

**Formatai.** `maskedmerge` reikalauja, kad visi trys srautai būtų to paties formato.
Naudojamas `gbrp`, nes `yuv420p` atveju kaukė paveiktų ir spalvų plokštumas. Kaukės
įvestis ribojama laike (`-loop 1 -t 24`), kitaip filtras laukia begalinio srauto.

## Vaizdo kokybė

Keturi dalykai, kurie realiai pakeitė rezultatą (patikrinta lyginant iškirptą veido
gabalą tikruoju dydžiu, detalumas pakilo nuo 2,53 iki 2,88):

1. **Aštrinti reikia gale, ne pradžioje.** Anksčiau `unsharp` stovėjo prie šaltinio, o
   paskui segmentai buvo didinami priartinimui, tad aštrumas vėl dingdavo. Dabar
   aštrinama po `crop`, galutinėje raiškoje.
2. **`hqdn3d=1.2:1.0:5:5` prie šaltinio.** Kambario apšvietime telefonas duoda triukšmo,
   kuris suėda bitus. Išvalius juos, tie patys bitai atitenka veidui. Stipriau nedėti,
   nes oda pradeda atrodyti plastikinė.
3. **`flags=lanczos` didinant.** Numatytasis didinimas priartintuose segmentuose
   pastebimai minkštesnis.
4. **CRF 17, `preset slow`, `aq-mode=3:psy-rd=1.0,0.15`.** Bitų srautas pakyla nuo
   9 iki 15 Mb/s. Instagram vis tiek perkoduos, bet iš geresnio originalo gauna geriau.

## Spalvų diapazonas: brangiausiai kainavusi klaida

Vaizdas gali būti pilno (`pc`, dar žymima `yuvj420p`) arba standartinio (`tv`) diapazono.
Pilną reikia suspausti į standartinį, kitaip Instagram perkoduodamas pakeičia kontrastą.
**Bet suspaudus jau suspaustą, kontrastas krenta apie 13 %, o spalvingumas apie 11 %.**
Vaizdas atrodo išplautas, ir iš pirmo žvilgsnio kaltinamas gradavimas, ne šis žingsnis.

iPhone `.mov` dažnai duoda `pc`, o ekrano įrašai ir dalis kamerų duoda `tv`. Todėl
`montazas.py` funkcija `saltinio_diapazonas()` pati perskaito šaltinį ir pertvarko tik
tada, kai reikia. Rankomis šito nustatinėti nereikia.

Patikra po renderio: iškirpti tą patį gabalą iš šaltinio ir iš rezultato, palyginti
šviesumo vidurkį, nuokrypį (kontrastas) ir kanalų skirtumą (spalvingumas). Švarus
montažas turi sutapti maždaug 1 % tikslumu.

## Kadravimas pagal veidą: ką verta žinoti

1. **Be priartėjimo kadro pajudinti neįmanoma.** Kai šaltinis jau 9:16, o segmento
   priartėjimas 1,00, ištemptas vaizdas sutampa su kadru ir vertikalios atsargos nėra
   visai. `VIRSUS` tokiuose segmentuose nieko nekeičia, kad ir kokį skaičių įrašytum.
   Norint lygiuoti veidą ir ten, segmentui reikia `z` bent 1,05.

2. **YuNet mato geriau nei Haar.** Antro darbo kadruose Haar rado veidą 15 kartų iš 18,
   YuNet 18 iš 18. YuNet dar duoda akių taškus, todėl kadras lygiuojamas pagal akių
   liniją ties 0,33 aukščio, kaip filmuojant, o ne pagal veido dėžutės vidurį.

3. **Skaičiai atitinka ranka rinktą skonį.** Antrame darbe rankinis `VIRSUS = 0,30`
   antrame segmente akis laikė ties 0,344, o skriptas siūlo 0,330. Didžiausias
   pataisymas yra paskutiniame segmente, kur priartėjimas stipriausias: akys buvo
   nusileidusios iki 0,420, o dabar keliamos į 0,330.

## Patikra: ką verta žinoti

1. **Vieno kadro lyginti neužtenka.** Priartintuose segmentuose vienas kadras nuo
   šaltinio skiriasi apie 1 %, nes vaizdas pertempiamas, o x264 su `aq-mode=3` šviesumą
   vietomis pastumia. Tai ne spalvų keitimas. Todėl `patikra.py` lygina vidurkius per
   visą video: antrame darbe bendras skirtumas 0,24 %, o pavienis kadras siekė 1,61 %.

2. **Subtitrai tikrinami iš ASS failo, ne iš vaizdo.** Ieškoma laike persidengiančių
   `Dialogue` įvykių, nes būtent dėl jų libass nustumia tekstą į kadro apačią.
   Tai tikrina priežastį, o ne pasekmę, todėl klaidingų pavojaus signalų nėra.

## Apdorojimo perjungikliai

`montazas.py` viršuje. Numatytoji būsena yra išjungta, nes šaltinio spalvų be prašymo
liesti nereikia:

- `GRADAVIMAS` — kontrastas ir spalvingumas
- `TRIUKSMO_VALYMAS` — `hqdn3d`
- `ASTRINIMAS` — 0 išjungta, apie 0,55 tinkama reikšmė
- `PROZEKTORIUS` — veidas šviesesnis, aplinka tamsesnė

## Perdavimas kitam kompiuteriui

Nieko iš to nereikia rašyti į kodą.

1. `pip install faster-whisper imageio-ffmpeg opencv-python pillow`
2. Video į `ivestis/`
3. `prekes-zenklas.pavyzdys.json` nusikopijuoti pavadinimu `prekes-zenklas.json`
   ir surašyti savo spalvas, šriftus, ženklo žodžius
4. `PYTHONIOENCODING=utf-8 python nustatymai.py` — patikrinti, ar viskas randama
5. Toliau įprasta eiga nuo `tylos.py`

Jeigu prireikė į `.py` failą rašyti kelią arba spalvą, vadinasi, kažkas praleista:
tai taisoma `nustatymai.py` arba `prekes-zenklas.json`, ne skripte. Tą saugo testas
`tests/test_nustatymai.py`.
